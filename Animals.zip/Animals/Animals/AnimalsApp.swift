//
//  AnimalsApp.swift
//  Animals
//
//  Created by Kurt McMahon on 3/4/21.
//

import SwiftUI

@main
struct AnimalsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
