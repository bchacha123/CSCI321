//
//  ContentView.swift
//  Animals
//
//  Created by Kurt McMahon on 3/4/21.
//

import SwiftUI

struct ContentView: View {
    
    @State private var sliderValue: CGFloat = 1
    
    let animals = ["🐅", "🦓", "🦍", "🐊", "🦤", "🦨", "🦒", "🦘"]
    
    private var columns: [GridItem] {
        return [
            GridItem(.adaptive(minimum: 280/sliderValue, maximum: 280/sliderValue))
        ]
    }

    var body: some View {
        VStack {
            Slider(value: $sliderValue, in: 1...8, step: 1)
                .padding()
            Text(String(format: "%.0f", sliderValue))
                .font(.system(size: 20))
                .bold()
                .padding()
                .background(Color.purple)
                .foregroundColor(.white)
                .clipShape(Circle())
            
            ScrollView {
                LazyVGrid(columns: columns, spacing: CGFloat(0)) {
                    ForEach(animals, id: \.self) {
                        animal in
                        Text("\(animal)")
                            .font(.system(size: CGFloat(280/sliderValue)))
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
