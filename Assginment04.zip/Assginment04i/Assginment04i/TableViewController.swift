//
//  TableViewController.swift
//  Assginment04i
//
//  Created by Brian Chacha on 3/18/21.
//

import UIKit
/**
 #TableViewController
 This class coresponds to the propiate functions that will be call that will display the list and will decay an error message in case the property list CANNOT be acceess.
 
 */
class TableViewController: UITableViewController
{
    var presidents: [PresidentsHistory] = []

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        loadPropertyList()
        
        presidents.sort
        {
            $0.number < $1.number
        }
    }

    func loadPropertyList() {
        guard let path = Bundle.main.path(forResource: "presidents", ofType: "plist"), let xml = FileManager.default.contents(atPath: path) else {
            fatalError("Cannot access the property list called, presidents.plist. Please try again!")
        }
        
        do {
            presidents = try PropertyListDecoder().decode([PresidentsHistory].self, from: xml)
        } catch {
            fatalError("Can't decode the preperty list, presidents.plist.")
        }
    }
    
    func string (from number: NSNumber) -> String?
    {
        let num = 1
        
        let formatter = NumberFormatter()
        
        formatter.numberStyle = .ordinal
        
        let number = formatter.string(from: NSNumber(value: num))
        
        return number
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        // #warning Incomplete implementation, return the number of rows
        return presidents.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Presidents", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = presidents[indexPath.row].presidentName
        
        cell.detailTextLabel?.text = presidents[indexPath.row].politicalParty

        return cell
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete
        {
            presidents.remove(at: indexPath.row)
            
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        }
        else if editingStyle == .insert
        {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }


    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "showDetail"
        {
            if let indexPath = tableView.indexPathForSelectedRow
            {
            let president = presidents[indexPath.row]
                
            let controller = segue.destination as! DetailViewController
                
            controller.detailedItem = president
            }
        }
    }
}
