//
//  DetailViewController.swift
//  Assginment04i
//
//  Created by Brian Chacha on 3/18/21.
//

import UIKit
/**
    #DetailViewController
     This class hold the connections between the mainstory board, along with other functions that will be call.
 */
class DetailViewController: UIViewController
{

    @IBOutlet weak var presidentsFirstName: UILabel!
    @IBOutlet weak var presidentsNumber: UILabel!
    @IBOutlet weak var timeStartEnd: UILabel!
    @IBOutlet weak var presidentsNickname: UILabel!
    @IBOutlet weak var presidentsPoliticalParty: UILabel!
    @IBOutlet weak var presidentImageView: UIImageView!
    
    var retainImages : RetainImages?
    
    var detailedItem: PresidentsHistory?
    {
        didSet
        {
            configureView()
        }
    }
    
    let formatter = NumberFormatter()
    
    var number = ""

    override func viewDidLoad()
    {
        
        super.viewDidLoad()
        
        formatter.numberStyle = .ordinal
        
        // Do any additional setup after loading the view.
        configureView()
    }

    /**
     #configureView
     This function makes the label change on the mainstory board 
     */
    func configureView()
    {
        // Update User interface with the fields of the detailed item.
        if let detail = detailedItem
        {
            if let presidentImageView = presidentImageView, let retainImages = retainImages
            {
                retainImages.downloadImage(from: detail.imageUrlString)
                {
                    image in
                    
                    presidentImageView.image = image
                    
                }
                
            }
            
            if let label = presidentsFirstName {
                label.text = detail.presidentName
            }
            if let label = presidentsNumber {
                number = formatter.string(from: NSNumber(value: detail.number))!
                label.text = "\(number) President of the United States."
            }
            if let label = timeStartEnd {
                label.text = "(\(detail.startYear) to \(detail.endYear))"
            }
            if let label = presidentsNickname {
                label.text = detail.nickName
            }
            if let label = presidentsPoliticalParty
            {
                label.text = detail.politicalParty
            }

        }
    }
}
