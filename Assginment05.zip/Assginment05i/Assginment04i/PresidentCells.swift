//
//  PresidentCells.swift
//  Assginment04i
//
//  Created by Brian Chacha on 3/30/21.
//

import UIKit
/**
 #PresudentCells
 This class hold the outlets for the user initual viwl view
 */
class PresidentCells: UITableViewCell
{
    
    @IBOutlet weak var imagePresidentCell: UIImageView!
    @IBOutlet weak var namePresidentCell: UILabel!
    @IBOutlet weak var partyPresidentCell: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    
    
}//End PresidentCells class
