//
//  PresidentsHistory.swift
//  Assginment04i
//
//  Created by Brian Chacha on 3/18/21.
//

import Foundation
/**
    # PresidentHistory
      This class hold the proper variables that will be call in "DetailViewController"
 */
class PresidentsHistory: Decodable
{
    var presidentName = ""
    var number = 0
    var startYear = ""
    var endYear = ""
    var nickName = ""
    var politicalParty = ""
    var imageUrlString = ""

    private enum CodingKeys: String, CodingKey
    {
        case presidentName = "Name"
        case number = "Number"
        case startYear = "Start Date"
        case endYear = "End Date"
        case nickName = "Nickname"
        case politicalParty = "Political Party"
        case imageUrlString = "URL"
    }

    init(presidentName: String, number: Int, startYear: String, endYear: String, nickName: String, politicalParty: String,
         imageUrlString: String = "None") {
        self.presidentName = presidentName
        self.number = number
        self.startYear = startYear
        self.endYear = endYear
        self.nickName = nickName
        self.politicalParty = politicalParty
    }
}
