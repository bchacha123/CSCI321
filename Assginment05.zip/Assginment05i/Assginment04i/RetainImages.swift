//
//  RetainImages.swift
//  Assginment04i
//
//  Created by Brian Chacha on 3/30/21.
//
import Foundation
import UIKit

/**
 #RetainImages
 This class holds error messages in case the images werent found/loaded properly along with the given URL
 */
class RetainImages {
    
    let imageCache = NSCache<NSString, UIImage>()
    
    func downloadImage(from urlString: String, completion: @escaping (_ image: UIImage?) -> Void)
    {
        
        if urlString == "None"
        {
            completion(UIImage(named: "seal.png"))
        } else if let cachedImage = imageCache.object(forKey: urlString as NSString) {
            completion(cachedImage)
        } else if let cachedImage = readImage(named: fileNameFrom(urlString)) {
            completion(cachedImage)
        } else {

            weak var weakSelf = self
            
            if let url = URL(string: urlString) {
            
                let task = URLSession.shared.dataTask(with: url) {
                    (data, response, error) in
                    
                    let httpResponse = response as? HTTPURLResponse
                    
                    if httpResponse!.statusCode != 200
                    {
                        // Perform some error handling
                        // UI updates, like alerts, should be directed to the main thread
                        DispatchQueue.main.async
                        {
                            print("HTTP Error: status code \(httpResponse!.statusCode)")
                            completion(UIImage(named: "seal.png"))
                        }
                        
                    } else if (data == nil && error != nil) {
                        // Perform some error handling
                        DispatchQueue.main.async {
                            print("No data downloaded for \(urlString)")
                            
                            completion(UIImage(named: "seal.png"))
                        }
                    } else {
                        // Download succeeded
                        if let image = UIImage(data: data!) {
                            DispatchQueue.main.async {
                                weakSelf!.imageCache.setObject(image, forKey: urlString as NSString)
                                
                                weakSelf!.saveImage(image, named: weakSelf!.fileNameFrom(urlString))
                                
                                completion(image)
                            }
                        } else {
                            DispatchQueue.main.async {
                                print("\(urlString) is not a valid image")
                                
                                completion(UIImage(named: "seal.png"))
                            }
                        }
                    }
                }
                
                task.resume()
            } else {
                DispatchQueue.main.async {
                    print("\(urlString) is not a valid URL")
                    
                    completion(UIImage(named: "default.png"))
                }
            }
        }
    }
    
    /**
        #fileNameFrom
        This class will return the final part of the image coming from the URL
     */
    private func fileNameFrom(_ urlString: String) -> String
    {
        let fileArray = urlString.components(separatedBy: "/")
        
        return fileArray.last!
    }
    
    /**
        #documentDirectory
        Returns the pathname of the app's documents directory.
     */
    private func documentDirectory() -> String
    {
        let documentDirectoryArray = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        
        return documentDirectoryArray[0]
    }
    
    /**
        #append
        Appends a filename to a specified path.
     */
    private func append(toPath path: String, withPathComponent pathComponent: String) -> String?
    {
        if var pathURL = URL(string: path) {
            pathURL.appendPathComponent(pathComponent)
            
            return pathURL.absoluteString
        }
        
        return nil
    }
    
    /**
        #SaveImage
        Saves an image to the disk cache.
     */
    func saveImage(_ image: UIImage, named fileName: String)
    {
        let fileManager = FileManager.default
        
        // Construct a pathname for the file to save by appending the file's name to
        // the pathname of the app's documents directory.
        
        guard let filePath = append(toPath: documentDirectory(), withPathComponent: fileName) else {
            return
        }
        
        // Create a file from the image at that pathname.
        
        let imageData = image.jpegData(compressionQuality: 1.0)
        fileManager.createFile(atPath: filePath, contents: imageData, attributes: nil)
    }
    
    /**
        #readImage
        Reads an image from the disk cache.
     */
    func readImage(named fileName: String) -> UIImage?
    {
        // Construct a pathname for the file to read by appending the file's name to
        // the pathname of the app's documents directory.

        guard let filePath = append(toPath: documentDirectory(), withPathComponent: fileName) else {
            return nil
        }

        // Read the file's data and return the image.
        
        return UIImage(contentsOfFile: filePath)
    }
    
    func clearCache()
    {
        imageCache.removeAllObjects()
    }
}
