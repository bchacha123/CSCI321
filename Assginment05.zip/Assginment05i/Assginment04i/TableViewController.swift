//
//  TableViewController.swift
//  Assginment04i
//
//  Created by Brian Chacha on 3/18/21.
//

import UIKit
/**
 #TableViewController
 This class coresponds to the propiate functions that will be call that will display the list and will decay an error message in case the property list CANNOT be acceess.
 
 */
class TableViewController: UITableViewController
{
    var presidents: [PresidentsHistory] = []
    
    let retainImages = RetainImages()

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        downloadJSONData()
    }

    
    func downloadJSONData()
    {
        
        guard let url = URL(string: "https://www.prismnet.com/~mcmahon/CS321/presidents.json") else {
            displayAlert("INCORRECT URL, PLEASE TRY AGAIN")
            
            return
        }
        
        weak var weakSelf = self
        
        let task = URLSession.shared.dataTask(with: url)
        {
            (data, response, error) in
            
            let httpResponse = response as? HTTPURLResponse
            
            if httpResponse!.statusCode != 200
            {
                // Perform some error handling
                // UI updates, like alerts, should be directed to the main thread
                weakSelf!.displayAlert("HTTP Error: status code \(httpResponse!.statusCode)")
                
            }
            else if (data == nil && error != nil)
            {
                // Perform some error handling
                weakSelf!.displayAlert("No data downloaded")
                
            }
            else
            {
                // Download succeeded
                do
                    {
                    weakSelf!.presidents = try JSONDecoder().decode([PresidentsHistory].self, from: data!)
                        
                    weakSelf!.presidents.sort
                    {
                        $0.number < $1.number
                    }
                    
                    DispatchQueue.main.async
                    {
                        weakSelf!.tableView!.reloadData()
                    }
                    
                } catch {
                    weakSelf!.displayAlert("Unable to decode JSON data")
                }
            }
        }
        
        task.resume()
    }
    
    
    func string (from number: NSNumber) -> String?
    {
        let num = 1
        
        let formatter = NumberFormatter()
        
        formatter.numberStyle = .ordinal
        
        let number = formatter.string(from: NSNumber(value: num))
        
        return number
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int { return 1 }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        // #warning Incomplete implementation, return the number of rows
        return presidents.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Presidents", for: indexPath) as! PresidentCells

        // Configure the cell...
        let president = presidents[indexPath.row]
        
        retainImages.downloadImage(from: president.imageUrlString)
        {
            image in
            
            cell.imagePresidentCell.image = image
        }
        cell.namePresidentCell?.text = president.presidentName
        
        cell.partyPresidentCell?.text = president.politicalParty

        return cell
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete
        {
            presidents.remove(at: indexPath.row)
            
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        }
        else if editingStyle == .insert
        {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }

    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "showDetail"
        {
            if let indexPath = tableView.indexPathForSelectedRow
            {
            let president = presidents[indexPath.row]
                
            let controller = segue.destination as! DetailViewController
                
            controller.detailedItem = president
                
            controller.retainImages = retainImages
            }
        }
    }
    
    /**
        This class will return an error message
     */
    func displayAlert(_ message: String)
    {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler:nil)
        
        alertController.addAction(cancelAction)
        
        DispatchQueue.main.async
        {
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    override func didReceiveMemoryWarning()
    {
        retainImages.clearCache()
    }
}
