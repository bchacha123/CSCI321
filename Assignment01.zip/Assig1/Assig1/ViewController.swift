//
//  ViewController.swift
//  Assig1
//
//  Created by Brian Chacha on 2/16/21.
//

import UIKit

class ViewController: UIViewController {
    
    // Connections
    @IBOutlet weak var titleLabel1: UILabel!
    @IBOutlet weak var titleLabel2: UILabel!
    @IBOutlet weak var userAgeInput: UITextField!
    @IBOutlet weak var resultAgeConversion: UILabel!
    @IBOutlet weak var imageAnimation: UIImageView!
    
    @IBAction func buttonPressed(_ sender: Any) {
        // Defining variables, and  inputting dogs age
        guard let number = userAgeInput.text, !number.isEmpty, let AgeEntered = Int(number)else {
            displayErrorMessage("Please enter an age for your dog!")
            return
            }
        
        var ageDog = 0
        
        if(AgeEntered == 1){
            ageDog = 15
        } else if (AgeEntered == 2){
            ageDog = 24
        } else if (AgeEntered > 2){
            ageDog = 24 + (AgeEntered  - 2) * 5
        }
        
        self.view.endEditing(true)
        
        resultAgeConversion.text = "Your dog is \(ageDog) in human years"
        resultAgeConversion.isHidden = false
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let tap = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing))
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view.
    }
    


    func displayErrorMessage(_ message: String){
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler:nil)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
    }

}



