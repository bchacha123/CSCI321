//
//  ViewController.swift
//  Assignment02
//
//  Created by Brian Chacha on 2/22/21.
//

import UIKit

class ViewController: UIViewController {
 
    // Connection for amount user will enter
    @IBOutlet weak var userInputValue: UITextField!
    
    // Connection to slider and lable of the tip percentage
    @IBOutlet weak var sliderTipPercentage: UISlider!
    @IBOutlet weak var tipAmtLabel: UILabel!
    
    // Connection to stepper and lable to number of memberss
    @IBOutlet weak var sizeAmtLabel: UILabel!
    @IBOutlet weak var stepperMembers: UIStepper!
    
    // Connection to total amounts
    @IBOutlet weak var totalBillLabel: UILabel!
    @IBOutlet weak var totalShareAmtLabel: UILabel!
        
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let tap = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing))
        view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view.
    }
    
/**
     This function will take user input and will out put the total amount of the bill along with the share of each individual membe
     
     Returns: The appropiate calculations
*/
    func calculation()
    {
        // storing the value the user enter and converting it to a double
        let amt = (userInputValue.text! as NSString).doubleValue

        let tipPer = sliderTipPercentage.value

        let tipAmt = amt * Double(tipPer) / 100

        //tipAmtLabel.text = "Tip Amount: \(round(tipAmt*100)/100)"
        tipAmtLabel.text = "Tip percent: \(round(sliderTipPercentage.value*100)/100)%"

        // Capturating the total amount
        let totalAmt = amt + tipAmt
        totalBillLabel.text = "Total Amount: $\(round(totalAmt*100)/100)"

        // Capturing the amout of people
        let shareNumber = Int(stepperMembers.value)

        sizeAmtLabel.text = "Total Members: \(shareNumber)"

        totalShareAmtLabel.text = "Your share: $\(round(totalAmt/Double(shareNumber)*100)/100)"

    }// End calculation amt

    /**
     This function takes the input from the steppeter and calls the calculation function
     */
    @IBAction func stepperMemChange(_ sender: Any)
    {
        calculation()
    }
    
    /**
     This function takes the input from the user text frield  and calls the calculation function
     */
    @IBAction func userIntputChange(_ sender: Any)
    {
        calculation()
    }


    /**
         This function takes the input base on the input the user entered
    */    @IBAction func tipPercentChange(_ sender: Any)
    {
        calculation()

    }

    /**
         This function takes the input base on the size the user entered
    */    @IBAction func sizeAmtChange(_ sender: Any)
    {
        calculation()
    }
    
}

