//
//  stopWatch.swift
//  Assignmet3
//
//  Created by Brian Chacha on 3/9/21.
//

import UIKit

/**
    This enum has the phases of the stopwatch, play, pause, stop
 */
enum clockPhases
{
    case run
    case pause
    case stop
}

/**
    Function: stopWatch
    
    This  function will have the outles of the what the storyboard needs along with
    addional functions that will be called within stopWatch.
 
    Retrurn: Will reurn an appropiate timer set by the User.
 */
class stopWatch: UIViewController
{

    // Outlets
    @IBOutlet weak var coundownPicker:  UIDatePicker!
    @IBOutlet weak var countdowntLabel: UILabel!
    @IBOutlet weak var toolPlayButton:  UIBarButtonItem!
    @IBOutlet weak var toolPauseButton: UIBarButtonItem!
    @IBOutlet weak var toolStopButton:  UIBarButtonItem!
    
    // Variables need for the upcoming functions
    var startTime = 0.0
    var time = 60.0
    var clock = Timer()
    
    // Phase [Stop] - Will stop the timer and bring it back to the original phase
    var clockphases: clockPhases = .stop
    
    // This function will enhance the program
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Calling settingDateFromSeconds function that will take the date and return a string
        coundownPicker.setDate(settingDateFromSeconds(seconds: 60) as Date, animated: true)
        
        // The new timing label
        changeTimingLabel()
        
        // Setting to false when user enters pause
        toolPauseButton.isEnabled = false
        
        startTime = coundownPicker.countDownDuration
        
        time = startTime
        
    }

    
    // This function will initialize the time and will go in to an if look in necessary
    @IBAction func decisionCountdownPicker(_ sender: UIDatePicker)
    {
        startTime = coundownPicker.countDownDuration
        
        if clockphases == .stop
        {
            time = startTime
            
            changeTimingLabel()
            
        }// End if loop
        
    }// End decisionCoundownPicker
    
    
    // This function will take the date and convert it to time
    func settingDateFromSeconds(seconds: Double) -> Date
    {
        let secondsInt = Int(seconds)
        
        let mins = (secondsInt / 60) % 60
        
        let hrs = secondsInt / 3600
        
        let dateString = String(format: "%0.2d:%0.2d", hrs, mins)

        let dateFormat = DateFormatter()
        
        dateFormat.dateFormat = "hh:mm"
        
        return dateFormat.date(from: dateString)!

    }
    
    // This function will update the label with the time picked by the user
    func changeTimingLabel()
    {
        let hr = Int(time) / 3600
        
        let restingTime = Int(time) - (hr * 3600)
        
        let min = restingTime / 60
        
        var minString = "\(min)"
        
        if min < 10
        {
            minString = "0\(min)"
        }
        
        let sec = restingTime % 60
        
        var secString = "\(sec)"
        
        if sec < 10
        {
            secString = "0\(sec)"
        }
        
        if (time < 3600)
        {
            countdowntLabel.text = "\(minString):\(secString)"
            
        } else {
            
            countdowntLabel.text = "\(hr):\(minString):\(secString)"
        }
    }
    
    // This function will decrease the given time
    @objc func decresingTimer()
    {
            
        time -= 1
        
        changeTimingLabel()
        
        if time == 0
        {
            pressStop(toolStopButton)
            
        }
    }
    // These functions are the button action based on what the user presses
    // This function will press play to the stopwatch
    @IBAction func pressPlay(_ sender: UIBarButtonItem)
    {
        clockphases = .run
        
        toolPlayButton.isEnabled = false
        
        toolPauseButton.isEnabled = true
        
        // Turing the clock back on and incrementing it by 1 second
        clock = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(decresingTimer), userInfo: nil, repeats: true)
        
    }// End pressPlay
    
    
    // This function will pause the stopwatch
    @IBAction func pressPause(_ sender: UIBarButtonItem)
    {
        toolPlayButton.isEnabled = true
        
        toolPauseButton.isEnabled = false
        
        clock.invalidate()
        
        clockphases = .pause
        
    }// End PressPause
    
    
    // This function will stop the stopwatch
    @IBAction func pressStop(_ sender: UIBarButtonItem)
    {
        toolPlayButton.isEnabled = true
        
        toolPauseButton.isEnabled = false
        
        clock.invalidate()
        
        clockphases = .stop
        
        startTime = coundownPicker.countDownDuration
        
        time = startTime
        
        decresingTimer()
        
    }
    
}
