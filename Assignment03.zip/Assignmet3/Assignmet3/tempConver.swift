//
//  tempConver.swift
//  Assignmet3
//
//  Created by Brian Chacha on 3/9/21.
//
import UIKit

/**
 Function: tempConver
 This function will read what the user enters as a conversion base on the picker view and will also print a conversion
 */
class tempConver: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource
{

    @IBOutlet weak var converterSegmentCt: UISegmentedControl!
    @IBOutlet weak var viewPicker: UIPickerView!
    @IBOutlet weak var conversionLabel: UILabel!
    
    var farhenheit: [Int] = []
    var celcius: [Int] = []
    
    
    // This function will call the given funtions that will do the converions
    @IBAction func changeConvertion(_ sender: UISegmentedControl)
    {
        viewPicker.reloadAllComponents()
        
        viewPicker.selectRow(0, inComponent: 0, animated: true)
        
        pickerView(viewPicker, didSelectRow: 0, inComponent: 0)
        
    }// End changeConvertion
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        viewPicker.delegate = self
        viewPicker.delegate = self
        
        //Creating a range for farhenheit in the picker view
        farhenheit += -129...134
        
        //Creating range for celcius in the picker view
        celcius += -90...57
        
        
        pickerView(viewPicker, didSelectRow: 0, inComponent: 0)
        
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        let row = pickerView.selectedRow(inComponent: 0)
        
        // This switch statement will print out to the user the appropiate conversions
        switch converterSegmentCt.selectedSegmentIndex
        {
        
        // Picked farhenheit
        case 0:
            let output = (farhenheit[row] - 32) * 5/9
            
            conversionLabel.text = "\(output)°C"
            
        // Picked celcius
        case 1:
            
            let output1 = (celcius[row] * 9/5) + 32
            
            conversionLabel.text = "\(output1)°F"
            
        default:
            
            break
        }
        
    }// End pickerView
    

    // This play the picker view
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if converterSegmentCt.selectedSegmentIndex == 0
        {
            return farhenheit.count
            
        } else {
            return celcius.count
        }
        
    }// End pickerView
    
    // This picker will return the given conversion
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        if converterSegmentCt.selectedSegmentIndex == 0
        {
            return "\(farhenheit[row])°F"
            
        } else {
            
            return "\(celcius[row])°C"
        }
    }// End pickerView
    
}
