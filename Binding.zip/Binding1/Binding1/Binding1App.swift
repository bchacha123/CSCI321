//
//  Binding1App.swift
//  Binding1
//
//  Created by Kurt McMahon on 3/23/21.
//

import SwiftUI

@main
struct Binding1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
