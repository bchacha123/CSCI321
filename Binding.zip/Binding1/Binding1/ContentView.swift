//
//  ContentView.swift
//  Binding1
//
//  Created by Kurt McMahon on 3/23/21.
//

import SwiftUI

struct ContentView: View {
    
    let episode = Episode(name: "Movies, Movies, Movies!", track: "PG: Psycho Goreman")
    
    @State private var isPlaying = false
    
    var body: some View {
        VStack {
            Text(episode.name)
                .font(.title)
                .foregroundColor(isPlaying ? .green : .black)
            Text(episode.track)
            PlayButton(isPlaying: $isPlaying)
                .padding(12)
        }
    }
}

struct PlayButton: View {
    
    @Binding var isPlaying: Bool

    var body: some View {
        Button("Play") {
            isPlaying.toggle()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
