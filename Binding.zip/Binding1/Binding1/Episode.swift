//
//  Episode.swift
//  Binding1
//
//  Created by Kurt McMahon on 3/23/21.
//

import Foundation

struct Episode {
    let name: String
    let track: String
}
