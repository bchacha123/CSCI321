//
//  ContentView.swift
//  Controls-Pt1
//
//  Created by Kurt McMahon on 4/3/21.
//

import SwiftUI

struct ContentView: View {
    
    let imageNames = ["bird", "cat", "dog"]
    
    @State private var selectedImage = 0
    @State private var opacity = 1.0
    
    var body: some View {
        GeometryReader { geometry in
            VStack {
                Image(imageNames[selectedImage])
                    .resizable()
                    .scaledToFit()
                    .frame(width: geometry.size.width, height: geometry.size.height*0.4)
                    .opacity(opacity)
                Picker("Image", selection: $selectedImage, content: {
                                Text("Bird").tag(0)
                                Text("Cat").tag(1)
                                Text("Dog").tag(2)
                })
                    .pickerStyle(SegmentedPickerStyle())
                    .padding()
                Stepper(value: $opacity, in: 0.0...1.0, step: 0.1, label: {
                    Text("Transparency")
                        .bold()
                })
                    .padding()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
