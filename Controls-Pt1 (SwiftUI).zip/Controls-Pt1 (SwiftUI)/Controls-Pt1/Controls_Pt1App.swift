//
//  Controls_Pt1App.swift
//  Controls-Pt1
//
//  Created by Kurt McMahon on 4/3/21.
//

import SwiftUI

@main
struct Controls_Pt1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
