//
//  ViewController.swift
//  Controls-Pt1
//
//  Created by Kurt McMahon on 2/4/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func segmentChanged(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            imageView.image = UIImage(named: "bird")
        case 1:
            imageView.image = UIImage(named: "cat")
        default:
            imageView.image = UIImage(named: "dog")
        }
    }
    
    @IBAction func stepTriggered(_ sender: UIStepper) {
        imageView.alpha = CGFloat(sender.value)
    }
}

