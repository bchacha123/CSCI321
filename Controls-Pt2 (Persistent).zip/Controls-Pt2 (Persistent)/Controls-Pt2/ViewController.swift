//
//  ViewController.swift
//  Controls-Pt2
//
//  Created by Kurt McMahon on 2/4/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    
    var red: Float = 0.0
    var green: Float = 0.0
    var blue: Float = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        readUserDefaults()
    }

    @IBAction func sliderMoved(_ sender: UISlider) {
        if sender == redSlider {
            red = redSlider.value
        } else if sender == greenSlider {
            green = greenSlider.value
        } else {
            blue = blueSlider.value
        }
        
        colorView.backgroundColor = UIColor(red: CGFloat(red), green: CGFloat(green), blue: CGFloat(blue), alpha: 1.0)
    }
    
    @IBAction func switchChanged(_ sender: UISwitch) {
        colorView.isHidden.toggle()
    }
    
    func writeUserDefaults() {
        let defaults = UserDefaults.standard
        
        defaults.set(red, forKey: "red")
        defaults.set(green, forKey: "green")
        defaults.set(blue, forKey: "blue")
        
        defaults.set(colorView.isHidden, forKey: "hidden")
    }

    func readUserDefaults() {
        let defaults = UserDefaults.standard
        
        red = defaults.float(forKey: "red")
        green = defaults.float(forKey: "green")
        blue = defaults.float(forKey: "blue")

        redSlider.value = red
        greenSlider.value = green
        blueSlider.value = blue
        
        colorView.backgroundColor = UIColor(red: CGFloat(red), green: CGFloat(green), blue: CGFloat(blue), alpha: 1.0)

        colorView.isHidden = defaults.bool(forKey: "hidden")
    }
    
}

