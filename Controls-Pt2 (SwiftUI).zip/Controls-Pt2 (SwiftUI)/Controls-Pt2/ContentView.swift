//
//  ContentView.swift
//  Controls-Pt2
//
//  Created by Kurt McMahon on 4/3/21.
//

import SwiftUI

struct ContentView: View {
    
    @State private var red = 0.0
    @State private var green = 0.0
    @State private var blue = 0.0
    
    @State private var showColor = true

    var body: some View {
        GeometryReader { geometry in
            VStack {
                Color(red: red, green: green, blue: blue, opacity: showColor ? 1.0 : 0.0)
                    .frame(height: geometry.size.height*0.4, alignment: .center)
                    .padding()
                HStack {
                    VStack(alignment: .leading) {
                        Text("Red")
                            .font(.headline)
                            .padding()
                        Text("Green")
                            .font(.headline)
                            .padding()
                        Text("Blue")                    .font(.headline)
                            .padding()
                    }
                    
                    VStack(alignment: .trailing, spacing: 30) {
                        Slider(value: $red, in: 0...1)
                            .padding(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16))
                        Slider(value: $green, in: 0...1)
                            .padding(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16))
                        Slider(value: $blue, in: 0...1)
                            .padding(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16))
                    }
                }
                
                Toggle(isOn: $showColor) {
                    Text("Show Color")
                        .font(.headline)
                }.padding()

            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
