//
//  Controls_Pt2App.swift
//  Controls-Pt2
//
//  Created by Kurt McMahon on 4/3/21.
//

import SwiftUI

@main
struct Controls_Pt2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
