//
//  ViewController.swift
//  Controls-Pt2
//
//  Created by Kurt McMahon on 2/4/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    
    var red: Float = 1.0
    var green: Float = 0.0
    var blue: Float = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func sliderMoved(_ sender: UISlider) {
        if sender == redSlider {
            red = redSlider.value
        } else if sender == greenSlider {
            green = greenSlider.value
        } else {
            blue = blueSlider.value
        }
        
        colorView.backgroundColor = UIColor(red: CGFloat(red), green: CGFloat(green), blue: CGFloat(blue), alpha: 1.0)
    }
    
    @IBAction func switchChanged(_ sender: UISwitch) {
        // colorView.isHidden = !sender.isOn
        colorView.isHidden.toggle()
    }
    
}

