//
//  ViewController.swift
//  DatePickerTest
//
//  Created by Kurt McMahon on 3/9/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var dateTextField: UITextField!
    
    let datePicker = UIDatePicker()
    let dateFormatter = DateFormatter()
    
    var date: Date = Date() {
        didSet {
            dateTextField.text = dateFormatter.string(from: date)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        dateFormatter.dateStyle = .long
        dateFormatter.timeStyle = .none
        
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 0, height: 44))
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(ViewController.dateSelected))
        let space = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolbar.setItems([space, doneButton, space], animated: false)

        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .wheels
        datePicker.addTarget(self, action: #selector(dateChanged), for: .valueChanged)
        
        dateTextField.inputAccessoryView = toolbar
        dateTextField.inputView = datePicker
    }
    
    @objc
    func dateChanged() {
        date = datePicker.date
    }

    @objc
    func dateSelected() {
        date = datePicker.date
        dateTextField.resignFirstResponder()
    }

}

