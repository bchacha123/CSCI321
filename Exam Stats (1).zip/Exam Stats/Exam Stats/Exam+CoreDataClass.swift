//
//  Exam+CoreDataClass.swift
//  Exam Stats
//
//  Created by Kurt McMahon on 11/9/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Exam)
public class Exam: NSManagedObject {

}
