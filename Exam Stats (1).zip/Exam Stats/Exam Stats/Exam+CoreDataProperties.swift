//
//  Exam+CoreDataProperties.swift
//  Exam Stats
//
//  Created by Kurt McMahon on 11/9/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//
//

import Foundation
import CoreData


extension Exam {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Exam> {
        return NSFetchRequest<Exam>(entityName: "Exam")
    }

    @NSManaged public var score: Int32
    @NSManaged public var name: String?

}
