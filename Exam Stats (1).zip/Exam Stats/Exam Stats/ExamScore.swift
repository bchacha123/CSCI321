//
//  ExamScore.swift
//  Exam Stats
//
//  Created by Kurt McMahon on 9/21/18.
//  Copyright © 2018 Northern Illinois University. All rights reserved.
//

import Foundation

struct ExamScore: Decodable {
    let name: String
    let score: Int32
}
