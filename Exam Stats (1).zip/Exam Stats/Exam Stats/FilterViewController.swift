//
//  FilterViewController.swift
//  Exam Stats
//
//  Created by Kurt McMahon on 11/16/17.
//  Copyright © 2017 Northern Illinois University. All rights reserved.
//

import UIKit
import CoreData

protocol FilterViewControllerDelegate: class {
    func filterViewController(filter: FilterViewController, didSelectPredicate predicate: NSPredicate?,sortDescriptor: NSSortDescriptor?)
}

class FilterViewController: UITableViewController {

    @IBOutlet var countLabels: [UILabel]!
    
    // Grades section
    @IBOutlet weak var gradeACell: UITableViewCell!
    @IBOutlet weak var gradeBCell: UITableViewCell!
    @IBOutlet weak var gradeCCell: UITableViewCell!
    @IBOutlet weak var gradeDCell: UITableViewCell!
    @IBOutlet weak var gradeFCell: UITableViewCell!
    
    // Statistics section
    @IBOutlet weak var averageLabel: UILabel!
    @IBOutlet weak var minimumLabel: UILabel!
    @IBOutlet weak var maximumLabel: UILabel!
    
    // Sort By section
    @IBOutlet weak var nameAZSortCell: UITableViewCell!
    @IBOutlet weak var nameZASortCell: UITableViewCell!
    @IBOutlet weak var scoreSortCell: UITableViewCell!
    
    var coreDataStack: CoreDataStack!
    weak var delegate: FilterViewControllerDelegate?
    var selectedSortDescriptor: NSSortDescriptor?
    var selectedPredicate: NSPredicate?

    lazy var gradeAPredicate: NSPredicate = {
        return NSPredicate(format: "%K BETWEEN {90, 100}", #keyPath(Exam.score))
    }()

    lazy var gradeBPredicate: NSPredicate = {
        return NSPredicate(format: "%K BETWEEN {80, 89}", #keyPath(Exam.score))
    }()

    lazy var gradeCPredicate: NSPredicate = {
        return NSPredicate(format: "%K BETWEEN {70, 79}", #keyPath(Exam.score))
    }()

    lazy var gradeDPredicate: NSPredicate = {
        return NSPredicate(format: "%K BETWEEN {60, 69}", #keyPath(Exam.score))
    }()
    
    lazy var gradeFPredicate: NSPredicate = {
        return NSPredicate(format: "%K BETWEEN {0, 59}", #keyPath(Exam.score))
    }()

    lazy var nameSortDescriptor: NSSortDescriptor = {
        let compareSelector = #selector(NSString.localizedStandardCompare(_:))
        return NSSortDescriptor(key: #keyPath(Exam.name), ascending: true, selector: compareSelector)
    }()
    
    lazy var scoreSortDescriptor: NSSortDescriptor = {
        return NSSortDescriptor(key: #keyPath(Exam.score), ascending: false)
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        populateCountLabel(for: countLabels[0], with: gradeAPredicate)
        populateCountLabel(for: countLabels[1], with: gradeBPredicate)
        populateCountLabel(for: countLabels[2], with: gradeCPredicate)
        populateCountLabel(for: countLabels[3], with: gradeDPredicate)
        populateCountLabel(for: countLabels[4], with: gradeFPredicate)
        populateCountLabel(for: countLabels[5], with: nil)
        
        populateAverageLabel()
        populateMaximumLabel()
        populateMinimumLabel()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func searchButtonTapped(_ sender: UIBarButtonItem) {
        delegate?.filterViewController(filter: self, didSelectPredicate: selectedPredicate, sortDescriptor: selectedSortDescriptor)
        dismiss(animated: true)
    }
    
    func populateCountLabel(for label: UILabel, with predicate: NSPredicate?) {
        let fetchRequest: NSFetchRequest<Exam> = Exam.fetchRequest()
        fetchRequest.predicate = predicate
        
        do {
            let count = try coreDataStack.managedContext.count(for: fetchRequest)
            label.text = "\(count)"
        } catch let error as NSError {
            print("Count not fetched \(error), \(error.userInfo)")
        }
    }

    func populateAverageLabel() {
        
        // 1
        let fetchRequest = NSFetchRequest<NSDictionary>(entityName: "Exam")
        fetchRequest.resultType = .dictionaryResultType
        
        // 2
        let avgExpressionDesc = NSExpressionDescription()
        avgExpressionDesc.name = "average"
        
        // 3
        let scoreExp = NSExpression(forKeyPath: #keyPath(Exam.score))
        avgExpressionDesc.expression = NSExpression(forFunction: "average:", arguments: [scoreExp])
        avgExpressionDesc.expressionResultType = .doubleAttributeType
        
        // 4
        fetchRequest.propertiesToFetch = [avgExpressionDesc]
        
        // 5
        do {
            let results = try coreDataStack.managedContext.fetch(fetchRequest)
            let resultDict = results.first!
            let average = resultDict["average"]!
            
            let formatter = NumberFormatter()
            formatter.numberStyle = .decimal
            formatter.minimumFractionDigits = 2
            formatter.maximumFractionDigits = 2
            averageLabel.text = formatter.string(from: average as! NSNumber)
        } catch let error as NSError {
            print("Count not fetch \(error), \(error.userInfo)")
        }
    }

    func populateMinimumLabel() {
        
        // 1
        let fetchRequest = NSFetchRequest<NSDictionary>(entityName: "Exam")
        fetchRequest.resultType = .dictionaryResultType
        
        // 2
        let minExpressionDesc = NSExpressionDescription()
        minExpressionDesc.name = "minimum"
        
        // 3
        let scoreExp = NSExpression(forKeyPath: #keyPath(Exam.score))
        minExpressionDesc.expression = NSExpression(forFunction: "min:", arguments: [scoreExp])
        minExpressionDesc.expressionResultType = .integer32AttributeType
        
        // 4
        fetchRequest.propertiesToFetch = [minExpressionDesc]
        
        // 5
        do {
            let results = try coreDataStack.managedContext.fetch(fetchRequest)
            let resultDict = results.first!
            let minimum = resultDict["minimum"]!
            
            minimumLabel.text = "\(minimum)"
        } catch let error as NSError {
            print("Count not fetch \(error), \(error.userInfo)")
        }
    }

    func populateMaximumLabel() {
        
        // 1
        let fetchRequest = NSFetchRequest<NSDictionary>(entityName: "Exam")
        fetchRequest.resultType = .dictionaryResultType
        
        // 2
        let maxExpressionDesc = NSExpressionDescription()
        maxExpressionDesc.name = "maximum"
        
        // 3
        let scoreExp = NSExpression(forKeyPath: #keyPath(Exam.score))
        maxExpressionDesc.expression = NSExpression(forFunction: "max:", arguments: [scoreExp])
        maxExpressionDesc.expressionResultType = .integer32AttributeType
        
        // 4
        fetchRequest.propertiesToFetch = [maxExpressionDesc]
        
        // 5
        do {
            let results = try coreDataStack.managedContext.fetch(fetchRequest)
            let resultDict = results.first!
            let maximum = resultDict["maximum"]!
            
            maximumLabel.text = "\(maximum)"
        } catch let error as NSError {
            print("Count not fetch \(error), \(error.userInfo)")
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) else {
            return
        }
        
        switch cell {
            
            // Grades section
            case gradeACell:
                selectedPredicate = gradeAPredicate
            case gradeBCell:
                selectedPredicate = gradeBPredicate
            case gradeCCell:
                selectedPredicate = gradeCPredicate
            case gradeDCell:
                selectedPredicate = gradeDPredicate
            case gradeFCell:
                selectedPredicate = gradeFPredicate
            
            //Sort By section
            case nameAZSortCell:
                selectedSortDescriptor = nameSortDescriptor
            case nameZASortCell:
                selectedSortDescriptor = nameSortDescriptor.reversedSortDescriptor as? NSSortDescriptor
            case scoreSortCell:
                selectedSortDescriptor = scoreSortDescriptor
            
            default: break
        }
        
        cell.accessoryType = .checkmark
    }
}
