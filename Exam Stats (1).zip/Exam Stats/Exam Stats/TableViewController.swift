//
//  TableViewController.swift
//  Exam Stats
//
//  Created by Kurt McMahon on 11/16/17.
//  Copyright © 2017 Northern Illinois University. All rights reserved.
//

import UIKit
import CoreData

class TableViewController: UITableViewController {

    var coreDataStack: CoreDataStack!
    var fetchRequest: NSFetchRequest<Exam>!
    var exams: [Exam] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        downloadJSONDataIfNeeded()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func fetchAndReload() {
        
        do {
            exams = try coreDataStack.managedContext.fetch(fetchRequest)
            tableView.reloadData()
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return exams.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "examCell", for: indexPath)

        let exam = exams[indexPath.row]

        // Configure the cell...
        cell.textLabel?.text = exam.name
        cell.detailTextLabel?.text = "\(exam.score)"

        return cell
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        guard segue.identifier == "toFilterViewController", let navController = segue.destination as? UINavigationController, let filterVC = navController.topViewController
            as? FilterViewController else {
                return
        }
        
        filterVC.coreDataStack = coreDataStack
        filterVC.delegate = self
    }

    @IBAction func unwindToTableViewController(_ segue: UIStoryboardSegue) {
    }
    
    // MARK: - Helper methods
    
    func downloadJSONDataIfNeeded() {
        fetchRequest = Exam.fetchRequest()
        let count = try! coreDataStack.managedContext.count(for: fetchRequest)
        
        guard count == 0 else {
            fetchAndReload()
            return
        }
        
        do {
            let results = try coreDataStack.managedContext.fetch(fetchRequest)
            results.forEach({ coreDataStack.managedContext.delete($0) })
            
            coreDataStack.saveContext()
            downloadJSONData()
        } catch let error as NSError {
            print("Error fetching: \(error), \(error.userInfo)")
        }
    }
    
    // Download JSON data
    func downloadJSONData() {
        
        guard let url = URL(string: "https://www.prismnet.com/~mcmahon/CS321/scores.json") else {
            // Perform some error handling
            print("Error: Invalid URL for JSON data.")
            return
        }

        let task = URLSession.shared.dataTask(with: url) {
            [weak self] (data, response, error) in
            
            let httpResponse = response as? HTTPURLResponse
            
            guard httpResponse!.statusCode == 200, data != nil, error == nil else {
                print("Error: No JSON data downloaded")
                return
            }

            // Download succeeded
            let array: [ExamScore]
            
            let examEntity = NSEntityDescription.entity(forEntityName: "Exam", in: self!.coreDataStack.managedContext)!
            
            do {
                array = try JSONDecoder().decode([ExamScore].self, from: data!)
                
            } catch {
                print("Unable to parse JSON data.")
                return
            }
            
            let privateMOC = NSManagedObjectContext(concurrencyType: .privateQueueConcurrencyType)
            privateMOC.parent = self!.coreDataStack.managedContext

            privateMOC.perform {
                for e in array {
                    let exam = Exam(entity: examEntity, insertInto: privateMOC)
                    exam.name = e.name
                    exam.score = e.score
                }

                do {
                    try privateMOC.save()
                    self!.coreDataStack.managedContext.performAndWait {
                        do {
                            try self!.coreDataStack.managedContext.save()
                        } catch {
                            fatalError("Failure to save context: \(error)")
                        }
                    }
                } catch {
                    fatalError("Failure to save context: \(error)")
                }
            
                DispatchQueue.main.async {
                    self!.fetchRequest = Exam.fetchRequest()
                    self!.fetchAndReload()
                }
            }
        }
        
        task.resume()
    }
}

extension TableViewController: FilterViewControllerDelegate {
    func filterViewController(filter: FilterViewController, didSelectPredicate predicate: NSPredicate?, sortDescriptor: NSSortDescriptor?) {
        fetchRequest.predicate = nil
        fetchRequest.sortDescriptors = nil
        fetchRequest.predicate = predicate
        
        if let sr = sortDescriptor {
            fetchRequest.sortDescriptors = [sr]
        }
        
        fetchAndReload()
    }
}

