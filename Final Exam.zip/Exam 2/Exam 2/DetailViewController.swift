//
//  DetailViewController.swift
//  Exam 2
//
//  Created by Kurt McMahon on 4/20/21.
//  Copyright © 2021 Northern Illinois University. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController
{
    //Question 4
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var departmentLabel: UILabel!
    @IBOutlet weak var salaryLabel: UILabel!
    
    

    func configureView() {
        // Update the user interface for the detail item.
        if let detail = detailItem
        {
            if let label = nameLabel
            {
                label.text = detail.nameLabel
            }
            if let label = departmentLabel
            {
                label.text = detail.departmentLabel
            }
            if let label = salaryLabel
            {
                label.text = String(format: "$%.02f", detail.salaryLabel)
            }

            
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        configureView()
    }

    var detailItem: Employee? {
        didSet {
            // Update the view.
            configureView()
        }
    }


}

