//
//  Employee.swift
//  Exam 2
//
//  Created by Brian Chacha on 4/21/21.
//

import Foundation

//Question 1
/*
 Class Name: Employee
 This class holds the variables needed for Employee
 */
class Employee: Decodable
{
    var nameLabel = ""
    var departmentLabel = ""
    var salaryLabel = 0.0
    
    public enum CodingKeys: String, CodingKey
    {
        case nameLabel = "Name"
        case departmentLabel = "Department"
        case salaryLabel = "Salary"
    }
    
    init(nameLabel: String, departmentLabel: String, salaryLabel: Double) {
        self.nameLabel = nameLabel
        self.departmentLabel = departmentLabel
        self.salaryLabel = salaryLabel
    }
    
}
