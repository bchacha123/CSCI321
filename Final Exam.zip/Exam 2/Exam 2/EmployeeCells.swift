//
//  EmployeeCells.swift
//  Exam 2
//
//  Created by Brian Chacha on 4/21/21.
//

import UIKit
/**
 #PresudentCells
 This class hold the outlets for the user initual viwl view
 */
class EmployeeCells: UITableViewCell
{
    
    @IBOutlet weak var nameEmployeeCell: UILabel!
    @IBOutlet weak var deparmentEmployeeCell: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    
    
}//End PresidentCells class
