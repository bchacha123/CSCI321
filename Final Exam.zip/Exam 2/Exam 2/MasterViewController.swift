//
//  MasterViewController.swift
//  Exam 2
//
//  Created by Kurt McMahon on 4/20/21.
//  Copyright © 2021 Northern Illinois University. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController
{

    var detailViewController: DetailViewController? = nil
    var employees = [Employee]()


    // MARK: - MasterViewController methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        navigationItem.leftBarButtonItem = editButtonItem
        
        readPropertyList()
        
        // EXTRA CREDIT  
        employees.sort
        {
            $0.nameLabel < $1.nameLabel
        }
    }

    func readPropertyList() {

        guard let path = Bundle.main.path(forResource: "Employee Data", ofType: "plist"), let xml = FileManager.default.contents(atPath: path) else {
            fatalError("Unable to access property list")
        }
        
        do
        {
            employees = try PropertyListDecoder().decode([Employee].self, from: xml)

        } catch {
            fatalError("Unable to decode property list")
        }
    }

    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let employee = employees[indexPath.row]
                let controller = segue.destination as! DetailViewController
                controller.detailItem = employee
            }
        }
    }

    // MARK: - UITableViewDataSource methods

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return employees.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! EmployeeCells

        let employee = employees[indexPath.row]

        // Configure the cell...
        
        cell.nameEmployeeCell?.text = employee.nameLabel
        
        cell.deparmentEmployeeCell?.text = employee.departmentLabel

        return cell
    }

    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            employees.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        }
    }


}

