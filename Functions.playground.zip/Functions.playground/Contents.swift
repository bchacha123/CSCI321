import UIKit

// Defining and calling a function

func greet(person: String) -> String {
    let greeting = "Hello, " + person + "!"
    return greeting
}

print(greet(person: "Anna"))
print(greet(person: "Brian"))

// Shorter version

func greetAgain(person: String) -> String {
    return "Hello again, " + person + "!"
}

print(greetAgain(person: "Anna"))

// Even shorter version - function with implicit return

func greetYetAgain(person: String) -> String {
    "Hello yet again, " + person + "!"
}

print(greetYetAgain(person: "Anna"))

// Function without parameters

func sayHelloWorld() -> String {
    "hello, world"
}

print(sayHelloWorld())

// Function without parameters or return value

func sayHelloWorldAgain() {
    print("hello, world")
}

sayHelloWorldAgain()

// Function with multiple parameters

func greet(person: String, alreadyGreeted: Bool) -> String {
    if alreadyGreeted {
        return greetAgain(person: person)
    } else {
        return greet(person: person)
    }
}

print(greet(person: "Tim", alreadyGreeted: true))

// Specifiying argument labels

func greet2(person: String, from hometown: String) -> String {
    "Hello \(person)!  Glad you could visit from \(hometown)."
}

print(greet2(person: "Bill", from: "Cupertino"))

// Omitting argument labels - most common pattern for non-initializer functions

func greetPerson(_ person: String, from hometown: String) -> String {
    "Hello \(person)!  Glad you could visit from \(hometown)."
}

print(greetPerson("Anne", from: "Chicago"))

// Default parameter values

func someFunction(parameterWithoutDefault: Int, parameterWithDefault: Int = 12) {
    print("\(parameterWithoutDefault), \(parameterWithDefault)")
}
someFunction(parameterWithoutDefault: 3, parameterWithDefault: 6)
someFunction(parameterWithoutDefault: 4)

// In-out parameters

func swapTwoInts(_ a: inout Int, _ b: inout Int) {
    let temp = a
    a = b
    b = temp
}

var x = 5, y = 7

print("Before swap: x = \(x), y = \(y)")
swapTwoInts(&x, &y)
print("After swap: x = \(x), y = \(y)")

