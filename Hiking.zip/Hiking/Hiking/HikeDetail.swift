//
//  HikeDetail.swift
//  Hiking
//
//  Created by Kurt McMahon on 3/4/21.
//

import SwiftUI

struct HikeDetail: View {
    let hike: Hike
    @State private var zoomed = false
    
    var body: some View {
        VStack {
            Image(hike.imageName)
                .resizable()
                .aspectRatio(contentMode: zoomed ? .fill : .fit)
                .onTapGesture {
                    withAnimation {
                        self.zoomed.toggle()
                    }
                }
            Text(hike.name)
                .font(.title)
            Text(String(format: "%1.f miles", hike.miles))
        }.navigationTitle(hike.name)
        .navigationBarTitleDisplayMode(.inline)

    }
}

struct HikeDetail_Previews: PreviewProvider {
    static var previews: some View {
        HikeDetail(hike: Hike(name: "Test Hike", imageName: "hike8", miles: 5.1))
    }
}
