//
//  HikingApp.swift
//  Hiking
//
//  Created by Kurt McMahon on 3/4/21.
//

import SwiftUI

@main
struct HikingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
