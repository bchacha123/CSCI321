//
//  AddCharacterViewController.swift
//  MCU
//
//  Created by Kurt McMahon on 2/23/21.
//

import UIKit

class AddCharacterViewController: UITableViewController, UITextFieldDelegate {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var realNameTextField: UITextField!
    @IBOutlet weak var allegianceTextField: UITextField!
    
    var character: MCUCharacter?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func displayAlert(_ message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "save" {
            guard let name = nameTextField.text, !name.isEmpty else {
                displayAlert("Please enter a name.")
                return false
            }
            guard let realName = realNameTextField.text, !realName.isEmpty else {
                displayAlert("Please enter a real name.")
                return false
            }
            guard let allegiance = allegianceTextField.text, !allegiance.isEmpty else {
                displayAlert("Please enter an allegiance.")
                return false
            }
        }
        
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "save" {
            if let name = nameTextField.text, let realName = realNameTextField.text, let allegiance = allegianceTextField.text {
                character = MCUCharacter(name: name, realName: realName, allegiance: allegiance)
            }
        }

    }
}
