//
//  MCUCharacter.swift
//  MCU
//
//  Created by Kurt McMahon on 2/18/21.
//

import Foundation

class MCUCharacter: Decodable {
    var name = ""
    var realName = ""
    var allegiance = ""
    
    private enum CodingKeys: String, CodingKey {
        case name = "Name"
        case realName = "Real Name"
        case allegiance = "Allegiance"
    }
    
    init(name: String, realName: String, allegiance: String) {
        self.name = name
        self.realName = realName
        self.allegiance = allegiance
    }
}
