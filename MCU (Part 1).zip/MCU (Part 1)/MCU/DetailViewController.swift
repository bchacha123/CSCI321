//
//  DetailViewController.swift
//  MCU
//
//  Created by Kurt McMahon on 2/18/21.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var realNameLabel: UILabel!
    @IBOutlet weak var allegianceLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    var detailItem: MCUCharacter? {
        didSet {
            configureView()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        configureView()
    }
    
    func configureView() {
        // Update user interface with the fields of the detail item
        
        if let detail = detailItem {
            if let label = nameLabel {
                label.text = detail.name
            }
            if let label = realNameLabel {
                label.text = detail.realName
            }
            if let label = allegianceLabel {
                label.text = detail.allegiance
            }
            if let imageView = imageView {
                imageView.image = UIImage(named: detail.name)
            }

        }
    }
}
