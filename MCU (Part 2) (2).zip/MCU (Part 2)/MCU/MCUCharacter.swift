//
//  MCUCharacter.swift
//  MCU
//
//  Created by Kurt McMahon on 2/18/21.
//

import Foundation

class MCUCharacter: Decodable {
    var name = ""
    var realName = ""
    var allegiance = ""
    var imageUrlString = ""
    
    private enum CodingKeys: String, CodingKey {
        case name = "Name"
        case realName = "Real Name"
        case allegiance = "Allegiance"
        case imageUrlString = "URL"
    }
    
    init(name: String, realName: String, allegiance: String, imageUrlString: String = "None") {
        self.name = name
        self.realName = realName
        self.allegiance = allegiance
        self.imageUrlString = imageUrlString
    }
}
