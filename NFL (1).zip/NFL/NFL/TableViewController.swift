//
//  TableViewController.swift
//  NFL
//
//  Created by Kurt McMahon on 11/5/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import UIKit
import CoreData

class TableViewController: UITableViewController {

    var coreDataStack: CoreDataStack!
    var fetchedResultsController: NSFetchedResultsController<Team>!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        fetchData()
        downloadJSONDataIfNeeded()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        guard let sections = fetchedResultsController.sections else {
            return 0
        }
        return sections.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let sectionInfo = fetchedResultsController.sections?[section] else {
            return 0
        }
        return sectionInfo.numberOfObjects
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let sectionInfo = fetchedResultsController.sections?[section]
        return sectionInfo?.name
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        // Configure the cell...
        configure(cell: cell, for: indexPath)

        return cell
    }

    func configure(cell: UITableViewCell, for indexPath: IndexPath) {
        guard let cell = cell as? TeamCell else {
            return
        }
        
        let team = fetchedResultsController.object(at: indexPath)
        
        cell.logoImageView.image = UIImage(named: team.imageName!)
        cell.teamLabel.text = team.teamName
        cell.scoreLabel.text = "Wins: \(team.wins)"
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let team = fetchedResultsController.object(at: indexPath)
        team.wins = team.wins + 1
        coreDataStack.saveContext()
        tableView.reloadData()
    }
    
    @IBAction func addTeam(_ sender: Any) {
        let alert = UIAlertController(title: "Secret Team", message: "Add a new team", preferredStyle: .alert)
        
        alert.addTextField {
            textField in
            textField.placeholder = "Team Name"
        }
        
        alert.addTextField {
            textField in
            textField.placeholder = "Division"
        }
        
        let saveAction = UIAlertAction(title: "Save", style: .default) {
            [unowned self] action in
            
            guard let nameTextField = alert.textFields?.first, let divisionTextField = alert.textFields?.last else {
                return
            }
            
            let team = Team(context: self.coreDataStack.managedContext)
            
            team.teamName = nameTextField.text
            team.division = divisionTextField.text
            team.imageName = team.teamName
            team.wins = 0
            
            self.coreDataStack.saveContext()
        }

        let cancelAction = UIAlertAction(title: "Cancel", style: .default)
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        present(alert, animated: true)
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func fetchData() {
        // 1
        let fetchRequest: NSFetchRequest<Team> = Team.fetchRequest()
        
        let divisionSort = NSSortDescriptor(key: #keyPath(Team.division), ascending: true)
        let scoreSort = NSSortDescriptor(key: #keyPath(Team.wins), ascending: false)
        let nameSort = NSSortDescriptor(key: #keyPath(Team.teamName), ascending: true)
        fetchRequest.sortDescriptors = [divisionSort, scoreSort, nameSort]
        
        fetchRequest.fetchBatchSize = 20
        
        // 2
        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: coreDataStack.managedContext, sectionNameKeyPath: #keyPath(Team.division), cacheName: "nfl")
        
        fetchedResultsController.delegate = self
        
        // 3
        do {
            try fetchedResultsController.performFetch()
        } catch let error as NSError {
            print("Fetching error: \(error), \(error.userInfo)")
        }
    }
    
    func downloadJSONDataIfNeeded() {
        let fetchRequest: NSFetchRequest<Team> = Team.fetchRequest()
        let count = try! coreDataStack.managedContext.count(for: fetchRequest)
        
        guard count == 0 else {
            fetchData()
            return
        }
        
        do {
            let results = try coreDataStack.managedContext.fetch(fetchRequest)
            results.forEach({
                coreDataStack.managedContext.delete($0)
            })
            
            coreDataStack.saveContext()
            downloadJSONData()
        } catch let error as NSError {
            print("Error fetching: \(error), \(error.userInfo)")
        }
    }
    
    func downloadJSONData() {
        guard let url = URL(string: "https://www.prismnet.com/~mcmahon/CS321/teams.json") else {
            // Perform some error handling
            print("Error: Invalid URL for JSON data.")
            return
        }
            
        let task = URLSession.shared.dataTask(with: url) {
            [weak self] (data, response, error) in
            
            let httpResponse = response as? HTTPURLResponse
            
            guard httpResponse!.statusCode == 200, data != nil, error == nil else {
                print("Error: No JSON data downloaded")
                return
            }
            
            // Download succeeded
            let array: [TeamData]
            //print(String(data: data!, encoding: .utf8) ?? "Nope")
            
            let teamEntity = NSEntityDescription.entity(forEntityName: "Team", in: self!.coreDataStack.managedContext)!
            
            do {
                array = try JSONDecoder().decode([TeamData].self, from: data!)
            } catch {
                print("Unable to parse JSON data.")
                return
            }
            
            let privateMOC = NSManagedObjectContext(concurrencyType: .privateQueueConcurrencyType)
            privateMOC.parent = self!.coreDataStack.managedContext
            
            privateMOC.perform {
                for t in array {
                    let team = Team(entity: teamEntity, insertInto: privateMOC)
                    team.teamName = t.teamName
                    team.division = t.division
                    team.wins = Int32(t.wins)
                    team.imageName = t.imageName
                }
                
                do {
                    try privateMOC.save()
                    self!.coreDataStack.managedContext.performAndWait {
                        do {
                            try self!.coreDataStack.managedContext.save()
                        } catch {
                            fatalError("Failure to save context: \(error)")
                        }
                    }
                } catch {
                    fatalError("Failure to save context: \(error)")
                }
                
                DispatchQueue.main.async {
                    self!.fetchData()
                }
            }
        }
        
        task.resume()
    }
}

extension TableViewController: NSFetchedResultsControllerDelegate {
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        
        switch type {
        case .insert:
            tableView.insertRows(at: [newIndexPath!], with: .automatic)
        case .delete:
            tableView.deleteRows(at: [indexPath!], with: .automatic)
        case .update:
            let cell = tableView.cellForRow(at: indexPath!) as! TeamCell
            configure(cell: cell, for: indexPath!)
        case .move:
            tableView.deleteRows(at: [indexPath!], with: .automatic)
            tableView.insertRows(at: [newIndexPath!], with: .automatic)
        default:
            print("Error")
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
        
        let indexSet = IndexSet(integer: sectionIndex)
        
        switch type {
        case .insert:
            tableView.insertSections(indexSet, with: .automatic)
        case .delete:
            tableView.deleteSections(indexSet, with: .automatic)
        default: break
        }
    }
}
