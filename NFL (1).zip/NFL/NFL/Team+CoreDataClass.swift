//
//  Team+CoreDataClass.swift
//  NFL
//
//  Created by Kurt McMahon on 11/10/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Team)
public class Team: NSManagedObject {

}
