//
//  Team+CoreDataProperties.swift
//  NFL
//
//  Created by Kurt McMahon on 11/10/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//
//

import Foundation
import CoreData


extension Team {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Team> {
        return NSFetchRequest<Team>(entityName: "Team")
    }

    @NSManaged public var teamName: String?
    @NSManaged public var division: String?
    @NSManaged public var imageName: String?
    @NSManaged public var wins: Int32

}
