//
//  TeamData.swift
//  NFL
//
//  Created by Kurt McMahon on 11/12/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import Foundation

class TeamData: Decodable
{
    var teamName: String
    var imageName: String
    var division: String
    var wins: Int
}
