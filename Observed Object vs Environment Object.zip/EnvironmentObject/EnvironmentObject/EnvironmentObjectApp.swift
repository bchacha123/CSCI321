//
//  EnvironmentObjectApp.swift
//  EnvironmentObject
//
//  Created by Kurt McMahon on 3/25/21.
//

import SwiftUI

@main
struct EnvironmentObjectApp: App {
    
    let userSettingsVM = UserSettingsVM()
    
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(userSettingsVM)
        }
    }
}
