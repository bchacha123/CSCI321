//
//  ScoreView.swift
//  ObservableObject3
//
//  Created by Kurt McMahon on 3/25/21.
//

import SwiftUI

struct ScoreView: View {
    
    @EnvironmentObject var userSettingsVM: UserSettingsVM
    
    var body: some View {
        VStack {
            Text("\(userSettingsVM.score)")
                .font(.largeTitle)
            Button("Increment Score") {
                userSettingsVM.score += 1
            }
            .padding()
            .background(Color.green)
            .cornerRadius(16)
        }
        .padding()
        .background(Color.orange)
    }
}

struct ScoreView_Previews: PreviewProvider {
    static var previews: some View {
        ScoreView()
    }
}
