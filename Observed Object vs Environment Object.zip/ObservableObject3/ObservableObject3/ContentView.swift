//
//  ContentView.swift
//  ObservableObject3
//
//  Created by Kurt McMahon on 3/25/21.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var userSettingsVM = UserSettingsVM()
    
    var body: some View {
        VStack {
            Text("\(userSettingsVM.score)")
                .font(.largeTitle)
                .padding()
            Button("Increment Score") {
                userSettingsVM.score += 1
            }
            
            ScoreView(score: $userSettingsVM.score)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
