//
//  ObservableObject3App.swift
//  ObservableObject3
//
//  Created by Kurt McMahon on 3/25/21.
//

import SwiftUI

@main
struct ObservableObject3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
