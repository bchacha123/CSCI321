//
//  ScoreView.swift
//  ObservableObject3
//
//  Created by Kurt McMahon on 3/25/21.
//

import SwiftUI

struct ScoreView: View {
    
    @Binding var score: Int
    
    var body: some View {
        VStack {
            Text("\(score)")
                .font(.largeTitle)
            Button("Increment Score") {
                score += 1
            }
            .padding()
            .background(Color.green)
            .cornerRadius(16)
        }
        .padding()
        .background(Color.orange)
    }
}

struct ScoreView_Previews: PreviewProvider {
    static var previews: some View {
        ScoreView(score: .constant(0))
    }
}
