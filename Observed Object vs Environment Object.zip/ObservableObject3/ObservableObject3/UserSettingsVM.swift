//
//  UserSettingsVM.swift
//  ObservableObject3
//
//  Created by Kurt McMahon on 3/25/21.
//

import Foundation
import SwiftUI

class UserSettingsVM: ObservableObject {
    @Published var score = 0
}
