//
//  Pet+CoreDataProperties.swift
//  Pets
//
//  Created by Kurt McMahon on 11/10/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//
//

import Foundation
import CoreData


extension Pet {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Pet> {
        return NSFetchRequest<Pet>(entityName: "Pet")
    }

    @NSManaged public var isFavorite: Bool
    @NSManaged public var lastWalked: Date?
    @NSManaged public var name: String?
    @NSManaged public var photoData: Data?
    @NSManaged public var rating: Double

}
