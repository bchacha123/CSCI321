//
//  PetData.swift
//  Pets
//
//  Created by Kurt McMahon on 10/28/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import Foundation

struct PetData: Decodable {
    let imageName: String
    let name: String
    let rating: Double
    let lastWalked: Date
    let isFavorite: Bool
}
