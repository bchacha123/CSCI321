//
//  ViewController.swift
//  Pets
//
//  Created by Kurt McMahon on 10/28/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var namePicker: UIPickerView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var lastWalkedLabel: UILabel!
    @IBOutlet weak var favoriteLabel: UILabel!
    
    var managedContext: NSManagedObjectContext!
    
    var currentPet: Pet!
    var petNames: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // 1
        insertData()
        
        // 2
        let request = NSFetchRequest<Pet>(entityName: "Pet")
        
        do {
            // 3
            let results = try managedContext.fetch(request)
            currentPet = results.first
            
            for pet in results {
                petNames.append(pet.name!)
            }
            
            namePicker.reloadAllComponents()
            
            // 4
            populate(pet: results.first!)
            
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
        
    }
    
    @IBAction func walk(_ sender: Any) {
        currentPet.lastWalked = Date()
        
        do {
            try managedContext.save()
            populate(pet: currentPet)
        } catch let error as NSError {
            print("Could not save \(error), \(error.userInfo)")
        }
    }
    
    @IBAction func rate() {
        let alert = UIAlertController(title: "New Rating", message: "Rate this pet", preferredStyle: .alert)
        alert.addTextField {
            (textField) in
            textField.keyboardType = .decimalPad
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default)
        let saveAction = UIAlertAction(title: "Save", style: .default) {
            [unowned self] action in
            
            guard let textField = alert.textFields?.first else {
                return
            }
            self.update(rating: textField.text)
        }
        alert.addAction(cancelAction)
        alert.addAction(saveAction)
        present(alert, animated: true)
    }
    
    func update(rating: String?) {
        guard let ratingString = rating, let rating = Double(ratingString) else {
            return
        }
        
        do {
            currentPet.rating = rating
            try managedContext.save()
            populate(pet: currentPet)
        } catch let error as NSError {
            if error.domain == NSCocoaErrorDomain && (error.code == NSValidationNumberTooLargeError || error.code == NSValidationNumberTooSmallError) {
                rate()
            } else {
                print("Could not save \(error), \(error.userInfo)")
            }
        }
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return petNames.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return petNames[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let selectedName = petNames[row]
        let request = NSFetchRequest<Pet>(entityName: "Pet")
        request.predicate = NSPredicate(format: "name == %@", selectedName)
        do {
            let results = try managedContext.fetch(request)
            currentPet = results.first
            populate(pet: currentPet)
            
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }

    func insertData() {
        
        // Check if PetData.plist data in Core Data
        
        let fetch = NSFetchRequest<Pet>(entityName: "Pet")
        let count = try! managedContext.count(for: fetch)
        if count > 0 {
            // PetData.plist data is already in Core Data
            return
        }
        
        guard let url = Bundle.main.url(forResource: "PetData", withExtension: ".plist"), let data: Data = try? Data(contentsOf: url) else {
            print("Unable to read property list")
            return
        }
        
        do {
            let decoder = PropertyListDecoder()
            let array = try decoder.decode([PetData].self, from: data)
            
            for p in array {
                let entity = NSEntityDescription.entity(forEntityName: "Pet", in: managedContext)!
                let pet = Pet(entity: entity, insertInto: managedContext)
                
                pet.name = p.name
                pet.rating = p.rating
                pet.lastWalked = p.lastWalked
                pet.isFavorite = p.isFavorite
                
                let image = UIImage(named: p.imageName)
                let photoData = image!.jpegData(compressionQuality: 1.0)!
                pet.photoData = Data(photoData)
            }
            
            try! managedContext.save()
            
        } catch {
            print("Unable to save Pet data to database: \(error.localizedDescription)")
        }
        
    }
    
    func populate(pet: Pet) {
        guard let imageData = pet.photoData as Data?, let lastWalked = pet.lastWalked as Date? else {
            return
        }
        
        imageView.image = UIImage(data: imageData)
        ratingLabel.text = "Rating: \(pet.rating)/5.0"
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .short
        lastWalkedLabel.text = "Last walked: " + dateFormatter.string(from: lastWalked)
        favoriteLabel.isHidden = !pet.isFavorite
    }
    
    
}

