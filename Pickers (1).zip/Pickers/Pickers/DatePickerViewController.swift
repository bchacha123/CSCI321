//
//  DatePickerViewController.swift
//  Pickers
//
//  Created by Kurt McMahon on 9/22/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import UIKit

class DatePickerViewController: UIViewController {
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func buttonPressed() {
        
        // Get selected item from Picker View
        let date = datePicker.date
        
        // Format the date and time
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateStyle = .full
        dateFormatter.timeStyle = .full
        
        let message = "The date and time you have selected is \(dateFormatter.string(from: date))"
        
        // Create and present Alert Controller
        let alertController = UIAlertController(title: "Date and Time Selected", message: message, preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }

    
}
