//
//  DependentComponentPickerViewController.swift
//  Pickers
//
//  Created by Kurt McMahon on 9/24/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import UIKit

struct State: Decodable {
    var stateName: String
    var zipCodes: [String]
}

class DependentComponentPickerViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var picker: UIPickerView!
    
    var stateArray: [State] = []
    var zips: [String] = []
    
    let stateComponent = 0
    let zipComponent = 1
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        guard let path = Bundle.main.path(forResource: "states", ofType: "plist"), let xml = FileManager.default.contents(atPath: path) else {
            fatalError("Unable to access property list states.plist")
        }
        
        do {
            stateArray = try PropertyListDecoder().decode([State].self, from: xml)
        } catch {
            fatalError("Unable to decode property list states.plist")
        }
        
        zips = stateArray[0].zipCodes
    }
    
    @IBAction func buttonPressed() {
        // Get selected item from Picker View
        let state = stateArray[picker.selectedRow(inComponent: stateComponent)].stateName
        let zip = zips[picker.selectedRow(inComponent: zipComponent)]
        
        // Create and present Alert Controller
        let alertController = UIAlertController(title: "You selected zip code \(zip)", message: "\(zip) is in \(state)", preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == stateComponent {
            return stateArray.count
        } else {
            return zips.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == stateComponent {
            return stateArray[row].stateName
        } else {
            return zips[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == stateComponent {
            zips = stateArray[row].zipCodes
            pickerView.selectRow(0, inComponent: zipComponent, animated: true)
            pickerView.reloadComponent(zipComponent)
        }
    }
}
