//
//  DoubleComponentViewController.swift
//  Pickers
//
//  Created by Kurt McMahon on 9/22/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import UIKit

class DoubleComponentViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var doublePicker: UIPickerView!
    
    let pickerData = [["Turkey", "Peanut Butter", "Tuna Salad", "Chicken Salad", "Roast Beef", "Vegemite"], ["Whole Wheat", "Rye", "Sourdough", "Seven Grain"]]
    
    // let fillingArray = ["Turkey", "Peanut Butter", "Tuna Salad", "Chicken Salad", "Roast Beef", "Vegemite"]
    // let breadArray = ["Whole Wheat", "Rye", "Sourdough", "Seven Grain"]
    
    let fillingComponent = 0
    let breadComponent = 1
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonPressed() {
        
        // Get selected item from Picker View
        let fillingType = pickerData[fillingComponent][doublePicker.selectedRow(inComponent: fillingComponent)]
        let breadType = pickerData[breadComponent][doublePicker.selectedRow(inComponent: breadComponent)]

        // Create and present Alert Controller
        let alertController = UIAlertController(title: "Thank you for your order", message: "Your \(fillingType) on \(breadType) will be right up!", preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "Great!", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    // MARK: Picker View Data Source methods

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return pickerData.count
        
        // return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData[component].count
        
        /*
        if component == fillingComponent {
            return fillingArray[row].count
        } else {
            return breadArray[row].count
        }
        */
    }
    
    // MARK: Picker View Delegate method
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[component][row]
        
        /*
        if component == fillingComponent {
            return fillingArray[row]
        } else {
            return breadArray[row]
        }
        */
    }

}
