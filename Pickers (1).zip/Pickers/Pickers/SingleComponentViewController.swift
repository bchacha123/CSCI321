//
//  SingleComponentViewController.swift
//  Pickers
//
//  Created by Kurt McMahon on 9/22/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import UIKit

class SingleComponentViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    // MARK: Outlets
    
    @IBOutlet weak var singlePicker: UIPickerView!
    
    // MARK: Properties
    
    let pickerData = ["Luke", "Leia", "Chewbacca", "R2-D2", "C-3PO", "Lando", "Rey", "Finn"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonPressed() {
        
        // Get selected item from Picker View
        let selected = pickerData[singlePicker.selectedRow(inComponent: 0)]
        
        // Create and present Alert Controller
        let alertController = UIAlertController(title: "You selected \(selected)", message: "Thank you for choosing.", preferredStyle: .alert)
        
        let cancelAction = UIAlertAction(title: "You're welcome", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    // MARK: Picker View Data Source methods
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    // MARK: Picker View Delegate method
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
}

