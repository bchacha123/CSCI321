//
//  ContentView.swift
//  Pickers
//
//  Created by Kurt McMahon on 4/3/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            SinglePickerView()
                .tabItem {
                    Label("Star Wars", image: "Star Wars")
                }
            DoublePickerView()
                .tabItem {
                    Label("Lunch", image: "Lunch")
                }
            DatePickerView()
                .tabItem {
                    Label("Date", image: "Date")
                }
            DependentPickerView()
                .tabItem {
                    Label("Zip Codes", image: "Zip Codes")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
