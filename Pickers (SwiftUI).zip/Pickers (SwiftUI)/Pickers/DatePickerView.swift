//
//  DatePickerView.swift
//  Pickers
//
//  Created by Kurt McMahon on 4/3/21.
//

import SwiftUI

struct DatePickerView: View {
    
    @State private var showingAlert = false
    @State private var selected = Date()
    
    var dateFormatter: DateFormatter {
        get {
            let formatter = DateFormatter()
            formatter.dateStyle = .long
            formatter.timeStyle = .long
            return formatter
        }
    }

    var body: some View {
        VStack {
            Text("Choose a Date")
                .font(.title)
                .bold()
                .padding()
            
            DatePicker("Choose a date", selection: $selected, displayedComponents: [.date, .hourAndMinute])
                .datePickerStyle(WheelDatePickerStyle())
            Button("Select") {
                showingAlert = true
            }
                .padding()
            Spacer()
        }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("Date and Time Selected"), message: Text("The date and time you have selected is \(dateFormatter.string(from: selected))"), dismissButton: .default(Text("OK")))
            }

    }
}

struct DatePickerView_Previews: PreviewProvider {
    static var previews: some View {
        DatePickerView()
    }
}
