//
//  DependentPickerView.swift
//  Pickers
//
//  Created by Kurt McMahon on 4/4/21.
//

import SwiftUI

struct DependentPickerView: View {
    
    @ObservedObject var dependentPickerVM = DependentPickerViewModel()
    
    @State private var stateIndex = 0
    @State private var zipIndex = 0
    
    @State private var showingAlert = false

    var body: some View {
        GeometryReader { geometry in

            VStack {
                Text("Choose a State and Zip Code")
                    .font(.title)
                    .bold()
                    .padding()
                HStack {
                    Picker("Choose a state", selection: $stateIndex) {
                        ForEach(dependentPickerVM.stateArray.indices, id: \.self) { index in
                            Text(dependentPickerVM.stateArray[index].stateName).tag(index)
                        }
                    }
                        .frame(width: geometry.size.width/2, alignment: .center)
                        .clipped()
                        .onChange(of: stateIndex) { tag in
                            dependentPickerVM.zips = dependentPickerVM.stateArray[tag].zipCodes
                            zipIndex = 0
                        }
                    Picker("Choose a zip code", selection: $zipIndex) {
                        ForEach(dependentPickerVM.zips, id: \.self) {
                            Text($0)
                        }
                    }
                        .frame(width: geometry.size.width/2, alignment: .center)
                        .clipped()
                }
                Button("Select") {
                    showingAlert = true
                }
                    .padding()
                Spacer()
            }
        }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("You selected zip code \(dependentPickerVM.zips[zipIndex])"), message: Text("\(dependentPickerVM.zips[zipIndex]) is in \(dependentPickerVM.stateArray[stateIndex].stateName)"), dismissButton: .default(Text("OK")))
            }
            .onAppear {
                dependentPickerVM.loadPropertyListData()
                
            }
    }
}

struct DependentPickerView_Previews: PreviewProvider {
    static var previews: some View {
        DependentPickerView()
    }
}
