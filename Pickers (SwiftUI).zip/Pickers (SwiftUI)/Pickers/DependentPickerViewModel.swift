//
//  DependentPickerViewModel.swift
//  Pickers
//
//  Created by Kurt McMahon on 4/4/21.
//

import Foundation
import SwiftUI

class DependentPickerViewModel: ObservableObject {
    
    @Published var stateArray: [StateModel] = []
    @Published var zips: [String] = []
    
    func loadPropertyListData() {
        guard let path = Bundle.main.path(forResource: "states", ofType: "plist"), let xml = FileManager.default.contents(atPath: path) else {
            fatalError("Unable to access property list states.plist")
        }
        
        do {
            stateArray = try PropertyListDecoder().decode([StateModel].self, from: xml)
        } catch {
            fatalError("Unable to decode property list states.plist")
        }
        
        zips = stateArray[0].zipCodes
    }
}
