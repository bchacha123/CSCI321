//
//  DoublePickerView.swift
//  Pickers
//
//  Created by Kurt McMahon on 4/3/21.
//

import SwiftUI

struct DoublePickerView: View {
    
    let pickerData = [["Turkey", "Peanut Butter", "Tuna Salad", "Chicken Salad", "Roast Beef", "Vegemite"], ["Whole Wheat", "Rye", "Sourdough", "Seven Grain"]]

    let fillingComponent = 0
    let breadComponent = 1

    @State private var fillingType = "Turkey"
    @State private var breadType = "Whole Wheat"
    @State private var showingAlert = false
    
    var body: some View {
        GeometryReader { geometry in

            VStack {
                Text("Choose Your Sandwich")
                    .font(.title)
                    .bold()
                    .padding()
                HStack {
                    Picker("Choose your filling", selection: $fillingType) {
                        ForEach(pickerData[fillingComponent], id: \.self) {
                            Text($0)
                        }
                    }
                        .frame(width: geometry.size.width/2, alignment: .center)
                        .clipped()
                    Picker("Choose your bread", selection: $breadType) {
                        ForEach(pickerData[breadComponent], id: \.self) {
                            Text($0)
                        }
                    }
                        .frame(width: geometry.size.width/2, alignment: .center)
                        .clipped()
                }
                Button("Select") {
                    showingAlert = true
                }
                    .padding()
                Spacer()
            }
        }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("Thank you for your order"), message: Text("Your \(fillingType) on \(breadType) will be right up!"), dismissButton: .default(Text("Great!")))
            }
    }
}

struct DoublePickerView_Previews: PreviewProvider {
    static var previews: some View {
        DoublePickerView()
    }
}
