//
//  PickersApp.swift
//  Pickers
//
//  Created by Kurt McMahon on 4/3/21.
//

import SwiftUI

@main
struct PickersApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
