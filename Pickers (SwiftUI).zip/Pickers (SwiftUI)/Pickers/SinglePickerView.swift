//
//  SinglePickerView.swift
//  Pickers
//
//  Created by Kurt McMahon on 4/3/21.
//

import SwiftUI

struct SinglePickerView: View {
    
    let pickerData = ["Luke", "Leia", "Chewbacca", "R2-D2", "C-3PO", "Lando", "Rey", "Finn"]

    @State private var showingAlert = false
    @State private var selected = "Luke"
    
    var body: some View {
        VStack {
            Text("Choose Your Favorite")
                .font(.title)
                .bold()
                .padding()
            
            Picker("Choose your favorite", selection: $selected) {
                ForEach(pickerData, id: \.self) {
                    Text($0)
                }
            }
            
            Button("Select") {
                showingAlert = true
            }
                .padding()
            Spacer()
        }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("You selected \(selected)"), message: Text("Thank you for choosing."), dismissButton: .default(Text("You're welcome")))
            }
    }
}

struct SinglePickerView_Previews: PreviewProvider {
    static var previews: some View {
        SinglePickerView()
    }
}
