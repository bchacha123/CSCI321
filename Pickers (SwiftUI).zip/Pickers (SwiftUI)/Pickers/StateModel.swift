//
//  StateModel.swift
//  Pickers
//
//  Created by Kurt McMahon on 4/4/21.
//

import Foundation

struct StateModel: Decodable {
    var stateName: String
    var zipCodes: [String]
}
