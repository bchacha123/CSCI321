//
//  DoubleComponentViewController.swift
//  Pickers
//
//  Created by Kurt McMahon on 9/22/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import UIKit

class DoubleComponentViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var doublePicker: UIPickerView!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonPressed() {
        
        // Get selected item from Picker View
        
        // Create and present Alert Controller
        
        /*
        let cancelAction = UIAlertAction(title: "Great!", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
        */
    }
    
    // MARK: Picker View Data Source methods

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 0
    }
    
    // MARK: Picker View Delegate method
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return ""
    }

}
