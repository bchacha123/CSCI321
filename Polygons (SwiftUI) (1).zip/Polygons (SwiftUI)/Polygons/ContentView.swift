//
//  ContentView.swift
//  Polygons
//
//  Created by Kurt McMahon on 4/14/21.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var polygonVM = PolygonViewModel()
    
    var polygonName: String {
        get {
            let polygonNames = ["Triangle", "Square", "Pentagon", "Hexagon", "Heptagon", "Octagon", "Nonagon", "Decagon", "Undecagon", "Dodecagon"]
            return polygonNames[polygonVM.numberOfSides - 3]
        }
    }
    
    var body: some View {
        GeometryReader { geometry in
            VStack {
                Text("Polygons")
                    .font(.title)
                    .bold()
                    .padding()
                
                Stepper(value: $polygonVM.numberOfSides, in: 3...12, step: 1, label: {
                    Text("Number of Sides")
                        .bold()
                })
                    .padding()
                
                HStack {
                    Text("Name:")
                        .bold()
                        .padding()
                    Spacer()
                    Text(polygonName)
                        .padding()
                }
                
                PolygonView(polygonVM: polygonVM)
                    .frame(height: geometry.size.height * 0.5)
                    .rotationEffect(Angle.degrees(polygonVM.degrees))
                    .gesture(MagnificationGesture()
                            .onChanged { value in
                                polygonVM.scale = value.magnitude
                    })
                    .simultaneousGesture(RotationGesture()
                            .onChanged({ angle in
                                polygonVM.degrees = angle.degrees
                    }))
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
