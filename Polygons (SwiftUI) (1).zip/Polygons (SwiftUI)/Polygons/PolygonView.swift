//
//  PolygonView.swift
//  Polygons
//
//  Created by Kurt McMahon on 4/14/21.
//

import SwiftUI
import Combine

struct PolygonView: View {
    
    @ObservedObject var polygonVM: PolygonViewModel;
    
    var body: some View {
        GeometryReader { geometry in
            Path { path in
                
                let points = polygonVM.pointsForPolygonWithCenter(CGPoint(x: geometry.size.width / 2.0, y: geometry.size.height / 2.0))
                path.move(to: points[0])
                
                for point in points {
                    path.addLine(to: point)
                }
            }
                .fill(Color.blue)
        }
    }
}

struct PolygonView_Previews: PreviewProvider {
    static var previews: some View {
        PolygonView(polygonVM: PolygonViewModel())
    }
}
