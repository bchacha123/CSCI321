//
//  PolygonViewModel.swift
//  Polygons
//
//  Created by Kurt McMahon on 4/14/21.
//

import Foundation
import SwiftUI

class PolygonViewModel: ObservableObject {
    
    @Published var degrees = 0.0
    @Published var scale: CGFloat = 0.9
    @Published var numberOfSides = 3
    
    func pointsForPolygonWithCenter(_ center: CGPoint) -> [CGPoint] {
        var result: [CGPoint] = []

        let smallestDimension = (center.x < center.y) ? center.x : center.y
        let radius = Double(scale) * Double(smallestDimension)
        
        let angle = (2.0 * Double.pi) / Double(numberOfSides)
        let exteriorAngle = Double.pi - angle
        let rotationDelta = angle - (0.5 * exteriorAngle)
        
        for currentAngle in 0..<numberOfSides {
            let newAngle = (angle * Double(currentAngle)) - rotationDelta
            let currentX = cos(newAngle) * radius
            let currentY = sin(newAngle) * radius
            let point = CGPoint(x: (center.x + CGFloat(currentX)), y: (center.y + CGFloat(currentY)))
            result.append(point)
        }

        return result
    }
}
