//
//  PolygonsApp.swift
//  Polygons
//
//  Created by Kurt McMahon on 4/14/21.
//

import SwiftUI

@main
struct PolygonsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
