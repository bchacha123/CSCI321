//
//  PolygonShape.swift
//  Polygons
//
//  Created by Kurt McMahon on 11/17/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import Foundation

class PolygonShape {
    
    var minSides = 3
    var maxSides = 12
    var numberOfSides = 3
    
    var name: String {
        get {
            let polygonNames = ["Triangle", "Square", "Pentagon", "Hexagon", "Heptagon", "Octagon", "Nonagon", "Decagon", "Undecagon", "Dodecagon"]
            return polygonNames[numberOfSides - 3]
        }
    }
    
    init(minSides: Int = 3, maxSides: Int = 12, numberOfSides: Int = 3) {
        self.minSides = minSides
        self.maxSides = maxSides
        self.numberOfSides = numberOfSides
    }
    
    func angleInDegrees() -> Double {
        return 180 * (Double(numberOfSides - 2) / Double(numberOfSides))
    }
    
    func angleInRadians() -> Double {
        return angleInDegrees() * (Double.pi / 180.0)
    }
}
