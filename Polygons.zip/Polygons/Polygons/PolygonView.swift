//
//  PolygonView.swift
//  Polygons
//
//  Created by Kurt McMahon on 11/16/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import UIKit

class PolygonView: UIView {

    var rotation: CGFloat = 0
    var scale: CGFloat = 0.9
    
    weak var delegate: PolygonViewDelegate?
    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        
        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }
        
        context.saveGState()
        
        // Rotate the context around the center of the polygon
        let contextCenter = CGPoint(x: bounds.midX, y: bounds.midY)
        context.translateBy(x: contextCenter.x, y: contextCenter.y)
        context.rotate(by: rotation)
        context.translateBy(x: -contextCenter.x, y: -contextCenter.y)

        // Get points for polygon
        let pointsArray = pointsForPolygonWithCenter(contextCenter)
        
        // Draw the polygon
        let path = UIBezierPath()
        path.move(to: pointsArray[0])
        
        for index in 1..<pointsArray.count {
            path.addLine(to: pointsArray[index])
        }
        
        path.close()
        
        UIColor.blue.setFill()
        UIColor.blue.setStroke()
        
        path.stroke()
        path.fill()
        
        UIGraphicsGetCurrentContext()!.restoreGState()
    }

    
    func pointsForPolygonWithCenter(_ center: CGPoint) -> [CGPoint] {
        var result: [CGPoint] = []
        
        let smallestDimension = (center.x < center.y) ? center.x : center.y
        let radius = Double(scale) * Double(smallestDimension)
        
        let angle = (2.0 * Double.pi) / Double(delegate!.numberOfSides())
        let exteriorAngle = Double.pi - angle
        let rotationDelta = angle - (0.5 * exteriorAngle)
        
        for currentAngle in 0..<delegate!.numberOfSides() {
            let newAngle = (angle * Double(currentAngle)) - rotationDelta
            let currentX = cos(newAngle) * radius
            let currentY = sin(newAngle) * radius
            let point = CGPoint(x: (center.x + CGFloat(currentX)), y: (center.y + CGFloat(currentY)))
            result.append(point)
        }
        return result
    }
    
    @IBAction func handlePinch(_ recognizer: UIPinchGestureRecognizer) {
        scale = recognizer.scale
        setNeedsDisplay()
    }
    
    @IBAction func handleRotate(_ recognizer: UIRotationGestureRecognizer) {
        rotation = recognizer.rotation
        setNeedsDisplay()
    }

}
