//
//  ViewController.swift
//  Polygons
//
//  Created by Kurt McMahon on 11/16/20.
//  Copyright © 2020 Northern Illinois University. All rights reserved.
//

import UIKit

protocol PolygonViewDelegate: class {
    func numberOfSides() -> Int
}

class ViewController: UIViewController, PolygonViewDelegate {

    @IBOutlet weak var numberOfSidesLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var numberOfSidesStepper: UIStepper!
    @IBOutlet weak var polygonView: PolygonView!
    
    var polygon: PolygonShape = PolygonShape()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        polygonView.delegate = self
        configureView()
    }

    @IBAction func stepperPressed(_ sender: UIStepper) {
        polygon.numberOfSides = Int(sender.value)
        configureView()
    }
    
    func configureView() {
        nameLabel.text = polygon.name
        numberOfSidesLabel.text = "\(polygon.numberOfSides)"
        polygonView.setNeedsDisplay()
    }
    
    func numberOfSides() -> Int {
        return polygon.numberOfSides
    }
}

