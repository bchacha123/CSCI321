//
//  ViewController.swift
//  Primes
//
//  Created by Kurt McMahon on 10/6/19.
//  Copyright © 2019 Northern Illinois University. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var timeButton: UIButton!
    @IBOutlet weak var showButton: UIButton!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var primesTextView: UITextView!
    
    var primesArray = [String]()
    let maxNum = 50000
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func startButtonPressed() {
        
        primesArray.removeAll(keepingCapacity: true)
        
        let startTime = Date().timeIntervalSinceReferenceDate
        
        DispatchQueue.global(qos: .userInitiated).async {
            var foundDivisor: Bool
            
            for i in 2...self.maxNum {
                foundDivisor = false
                
                var divisor = i - 1
                
                while divisor > 1 && !foundDivisor {
                    if i % divisor == 0 {
                        foundDivisor = true
                    }
                    
                    divisor -= 1
                }
                
                if !foundDivisor {
                    self.primesArray.append("Prime: \(i)")
                    DispatchQueue.main.async {
                        self.statusLabel.text = "Prime: \(i)"
                    }
                }
            }
            
            // All primes have been found.
            DispatchQueue.main.async {
                let stopTime = Date().timeIntervalSinceReferenceDate
                let elapsedTime = stopTime - startTime
                
                self.statusLabel.text = "Done: elapsed time = \(elapsedTime)"
                self.showButton.isEnabled = true
            }
        }
    }
    
    @IBAction func clearButtonPressed() {
        statusLabel.text = ""
        timeLabel.text = ""
        primesTextView.text = ""
        
        showButton.isEnabled = false
    }
    
    @IBAction func timeButtonPressed() {
        timeLabel.text = Date().description
    }
    
    @IBAction func showButtonPressed() {
        
        var primesList = "Number of primes: \(primesArray.count)\n"
        
        for primeNumber in primesArray {
            primesList = primesList + "\(primeNumber)\n"
        }
        
        primesTextView.text = primesList;
    }
}

