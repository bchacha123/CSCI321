import UIKit

let xml = """
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<array>
    <string>chicken</string>
    <string>cow</string>
    <string>alligator</string>
    <string>elephant</string>
    <string>dolphin</string>
    <string>dog</string>
    <string>cat</string>
    <string>gorilla</string>
    <string>eagle</string>
</array>
</plist>
""".data(using: .utf8)!

let array = try! PropertyListDecoder().decode([String].self, from: xml)
print(array)
print(array[0])
