//
//  ContentView.swift
//  ObservedObject1
//
//  Created by Kurt McMahon on 3/23/21.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var fancyTimerVM = FancyTimerVM()
    
    var body: some View {
        Text("\(fancyTimerVM.value)")
            .font(.largeTitle)
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
