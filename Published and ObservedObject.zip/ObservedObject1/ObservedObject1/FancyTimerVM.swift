//
//  FancyTimerVM.swift
//  ObservedObject1
//
//  Created by Kurt McMahon on 3/23/21.
//

import Foundation
import SwiftUI

class FancyTimerVM: ObservableObject {
    
    @Published var value: Int = 0
    
    init() {
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) {
            _ in
            self.value += 1
        }
    }
}
