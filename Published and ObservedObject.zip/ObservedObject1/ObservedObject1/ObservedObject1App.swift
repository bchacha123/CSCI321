//
//  ObservedObject1App.swift
//  ObservedObject1
//
//  Created by Kurt McMahon on 3/23/21.
//

import SwiftUI

@main
struct ObservedObject1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
