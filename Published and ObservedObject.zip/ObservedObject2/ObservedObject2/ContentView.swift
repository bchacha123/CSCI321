//
//  ContentView.swift
//  ObservedObject2
//
//  Created by Kurt McMahon on 3/23/21.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var userSettingsVM = UserSettingsVM()
    
    var body: some View {
        VStack {
            Text("\(userSettingsVM.score)")
                .font(.largeTitle)
                .padding()
            Button("Increment Score") {
                userSettingsVM.incrementScore()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
