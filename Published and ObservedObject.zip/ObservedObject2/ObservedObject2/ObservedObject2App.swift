//
//  ObservedObject2App.swift
//  ObservedObject2
//
//  Created by Kurt McMahon on 3/23/21.
//

import SwiftUI

@main
struct ObservedObject2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
