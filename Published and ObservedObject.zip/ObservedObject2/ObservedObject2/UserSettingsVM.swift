//
//  UserSettingsVM.swift
//  ObservedObject2
//
//  Created by Kurt McMahon on 3/23/21.
//

import Foundation
import SwiftUI

class UserSettingsVM: ObservableObject {
    @Published var score: Int = 0
    
    func incrementScore() {
        score += 1
    }
}
