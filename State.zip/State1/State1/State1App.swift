//
//  State1App.swift
//  State1
//
//  Created by Kurt McMahon on 3/9/21.
//

import SwiftUI

@main
struct State1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
