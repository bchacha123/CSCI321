//
//  ContentView.swift
//  State2
//
//  Created by Kurt McMahon on 3/23/21.
//

import SwiftUI

struct ContentView: View {
    
    var dishes = Dish.all()
    
    @State private var isSpicy = false
    
    var body: some View {
        List {
            Toggle(isOn: $isSpicy) {
                Text("Spicy")
                    .font(.title)
            }
            ForEach(dishes.filter {$0.isSpicy == isSpicy}) { dish in
                HStack {
                    Image(dish.imageName)
                        .resizable()
                        .frame(width: 100, height: 100)
                    Text(dish.name)
                        .font(.title)
                    Spacer()
                    if dish.isSpicy {
                        Image("spicy-icon")
                            .resizable()
                            .frame(width: 35, height: 35)
                    }
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
