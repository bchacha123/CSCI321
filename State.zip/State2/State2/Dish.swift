//
//  Dish.swift
//  Binding1
//
//  Created by Kurt McMahon on 3/9/21.
//

import Foundation
import SwiftUI

struct Dish: Identifiable {
    let id = UUID()
    let name: String
    let imageName: String
    let isSpicy: Bool
}

extension Dish {
    static func all() -> [Dish] {
        return [
            Dish(name: "Sushi", imageName: "sushi", isSpicy: false),
            Dish(name: "Kung Pao Chicken", imageName: "kung pao chicken", isSpicy: true),
            Dish(name: "Filet Mignon", imageName: "filet mignon", isSpicy: false),
            Dish(name: "Chocolate Cake", imageName: "chocolate cake", isSpicy: false),
            Dish(name: "Spicy Red Chicken", imageName: "spicy red chicken", isSpicy: true)
        ]
    }
}
