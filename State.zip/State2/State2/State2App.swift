//
//  State2App.swift
//  State2
//
//  Created by Kurt McMahon on 3/23/21.
//

import SwiftUI

@main
struct State2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
