//
//  ContentView.swift
//  State3
//
//  Created by Kurt McMahon on 3/23/21.
//

import SwiftUI

struct ContentView: View {
    
    @State private var name = ""
    
    private func printName() {
        print(name)
    }
    
    var body: some View {
        VStack {
            Text(name)
                .padding()
            TextField("Enter name", text: $name)
                .padding()
            Button(action: printName) {
                Text("Show Name Value")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
