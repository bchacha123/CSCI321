//
//  State3App.swift
//  State3
//
//  Created by Kurt McMahon on 3/23/21.
//

import SwiftUI

@main
struct State3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
