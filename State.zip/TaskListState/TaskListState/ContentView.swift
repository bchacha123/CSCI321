//
//  ContentView.swift
//  TaskListState
//
//  Created by Kurt McMahon on 3/9/21.
//

import SwiftUI

struct ContentView: View {
    
    @State private var tasks = Task.all()
    
    var body: some View {
        List {
            Button(action: addTask) {
                Text("Add Task")
            }
            
            ForEach(tasks) { task in
                Text(task.name)
            }
        }
        
    }
    
    private func addTask() {
        tasks.append(Task(name: "Wash the car"))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
