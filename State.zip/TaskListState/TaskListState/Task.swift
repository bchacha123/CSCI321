//
//  Task.swift
//  TaskListState
//
//  Created by Kurt McMahon on 3/9/21.
//

import Foundation
import SwiftUI

struct Task: Identifiable {
    let id = UUID()
    let name: String
    
    static func all() -> [Task] {
        return [
            Task(name: "Eat dinner"),
            Task(name: "Walk the dog"),
            Task(name: "Call my mom")
        ]
    }
}


