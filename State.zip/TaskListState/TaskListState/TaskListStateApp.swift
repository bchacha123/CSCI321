//
//  TaskListStateApp.swift
//  TaskListState
//
//  Created by Kurt McMahon on 3/9/21.
//

import SwiftUI

@main
struct TaskListStateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
