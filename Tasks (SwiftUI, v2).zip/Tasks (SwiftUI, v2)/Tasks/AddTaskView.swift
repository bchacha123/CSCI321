//
//  AddTaskView.swift
//  Tasks
//
//  Created by Kurt McMahon on 4/1/21.
//

import SwiftUI

struct AddTaskView: View {
    
    @Environment(\.managedObjectContext) private var viewContext

    @State private var taskName = ""
    @State private var showingAlert = false
    @State private var alertMessage = ""
    
    @Binding var isPresented: Bool

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("TASK NAME").font(.body)) {     TextField("Enter a task", text: $taskName)
                }
            }
            .navigationBarItems(leading: Button("Cancel", action: {
                isPresented = false
            }), trailing: Button("Save", action: {
                if taskName.isEmpty {
                    alertMessage = "Please enter a task name"
                    showingAlert = true
                } else {
                    addTask()
                    isPresented = false
                }
            }))
                .navigationTitle("Add Task")
                .navigationBarTitleDisplayMode(.inline)
        }
            .alert(isPresented: $showingAlert) {
                Alert(title: Text("Error"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
            }
        
    }
    
    private func addTask() {
        withAnimation {
            let newTask = Task(context: viewContext)
            newTask.name = taskName

            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}

struct AddTaskView_Previews: PreviewProvider {
    static var previews: some View {
        AddTaskView(isPresented: .constant(false))
    }
}
