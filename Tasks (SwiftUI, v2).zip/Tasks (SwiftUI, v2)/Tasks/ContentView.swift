//
//  ContentView.swift
//  Tasks
//
//  Created by Kurt McMahon on 4/1/21.
//

import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext

    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Task.name, ascending: true)],
        animation: .default)
    private var tasks: FetchedResults<Task>
    
    @State private var isPresented = false
    
    var body: some View {
        NavigationView {
            
            List {
                ForEach(tasks) { task in
                    NavigationLink(destination: DetailView(taskName: task.name!)) {
                        Text("\(task.name!)")
                    }
                }
                .onDelete(perform: deleteTasks)
            }
            .listStyle(PlainListStyle())
            .sheet(isPresented: $isPresented, content: {
                AddTaskView(isPresented: self.$isPresented)
            })
            .navigationBarItems(leading: EditButton(), trailing: Button(action: {
                isPresented = true
            }, label: {
                Image(systemName: "plus")
            }))
            .navigationTitle("To Do List")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func deleteTasks(offsets: IndexSet) {
        withAnimation {
            offsets.map { tasks[$0] }.forEach(viewContext.delete)

            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
