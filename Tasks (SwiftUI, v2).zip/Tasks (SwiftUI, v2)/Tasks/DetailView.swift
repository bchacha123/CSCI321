//
//  DetailView.swift
//  Tasks
//
//  Created by Kurt McMahon on 4/5/21.
//

import SwiftUI

struct DetailView: View {
    
    var taskName: String
    
    var body: some View {
        VStack {
            Text(taskName)
                .font(.title)
        }
        .navigationTitle("Details")
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(taskName: "A Task")
    }
}
