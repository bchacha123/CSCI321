//
//  MasterViewController.swift
//  Tasks
//
//  Created by Kurt McMahon on 3/30/21.
//

import UIKit
import CoreData

class MasterViewController: UITableViewController {

    var persistence: Persistence!
    var tasks: [Task] = []
    
    lazy var sortDescriptor: NSSortDescriptor = {
        let compareSelector = #selector(NSString.localizedStandardCompare(_:))
        return NSSortDescriptor(key: #keyPath(Task.name), ascending: true, selector: compareSelector)
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        self.navigationItem.leftBarButtonItem = self.editButtonItem
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fetch()
    }

    @IBAction func addTask(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "New Task", message: "Please enter a new task", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        let saveAction = UIAlertAction(title: "Save", style: .default, handler: {
            [unowned self] action in
            
            guard let textField = alert.textFields?.first, let taskNameToSave = textField.text, !taskNameToSave.isEmpty else {
                return
            }
            
            self.save(taskName: taskNameToSave)
            self.tableView.reloadData()
        })
        
        alert.addTextField()
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true)
    }
    
    func save(taskName: String) {
        
        let entity = NSEntityDescription.entity(forEntityName: "Task", in: persistence.context)
        let task = Task(entity: entity!, insertInto: persistence.context)
        task.name = taskName
        
        // Additional lines to set other attributes
        
        persistence.saveContext()
        fetch()
    }
    
    func fetch() {
        let fetchRequest = NSFetchRequest<Task>(entityName: "Task")
        fetchRequest.sortDescriptors = [sortDescriptor]

        do {
            tasks = try persistence.context.fetch(fetchRequest)
        } catch let error as NSError {
            print("Fetch error: \(error), description: \(error.userInfo)")
        }
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = tasks[indexPath.row].name

        return cell
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            let taskToDelete = tasks[indexPath.row]
            persistence.context.delete(taskToDelete)
            persistence.saveContext()
            
            tasks.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "showDetail" {
             if let indexPath = tableView.indexPathForSelectedRow {
                 let task = tasks[indexPath.row]
                 let controller = segue.destination as! DetailViewController
                 controller.detailItem = task
             }
        }
    }
}
