//
//  AddTaskViewController.swift
//  Books
//
//  Created by Kurt McMahon on 3/30/21.
//

import UIKit
import CoreData

class AddTaskViewController: UITableViewController, UITextFieldDelegate {

    @IBOutlet weak var nameTextField: UITextField!
    
    var persistence: Persistence!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func displayAlert(_ message: String) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "save" {
            guard let name = nameTextField.text, !name.isEmpty else {
                displayAlert("Please enter a task name.")
                return false
            }
        }
        
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "save" {
            saveTask()
        }
    }
    
    func saveTask() {
        if let name = nameTextField.text {
        
            let entity = NSEntityDescription.entity(forEntityName: "Task", in: persistence.context)
            let task = Task(entity: entity!, insertInto: persistence.context)
            task.name = name
            persistence.saveContext()
        }
    }
}
