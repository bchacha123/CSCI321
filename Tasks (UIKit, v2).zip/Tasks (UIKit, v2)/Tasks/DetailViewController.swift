//
//  DetailViewController.swift
//  Tasks
//
//  Created by Kurt McMahon on 4/1/21.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    var detailItem: Task? {
        didSet {
            configureView()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        configureView()
    }
    
    func configureView() {
        // Update user interface with the fields of the detail item
        
        if let detail = detailItem {
            if let label = nameLabel {
                label.text = detail.name
            }
        }
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
}
