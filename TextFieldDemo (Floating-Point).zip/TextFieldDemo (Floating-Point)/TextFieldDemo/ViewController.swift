//
//  ViewController.swift
//  TextFieldDemo
//
//  Created by Kurt McMahon on 2/2/21.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var firstNumberTextField: UITextField!
    @IBOutlet weak var secondNumberTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    let formatter = NumberFormatter()
    
    // MARK: ViewController methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
    }

    @IBAction func buttonPressed() {
        
        firstNumberTextField.resignFirstResponder()
        secondNumberTextField.resignFirstResponder()
        
        // Get first number and convert it to an integer
        guard let firstNumberString = firstNumberTextField.text, !firstNumberString.isEmpty, let firstNumber = Double(firstNumberString) else {
            // print("Error - invalid first number")
            displayError("Please enter a valid first number", textField: firstNumberTextField)
            return
        }
        
        // Get second number and convert it to an integer
        guard let secondNumberString = secondNumberTextField.text, !secondNumberString.isEmpty, let secondNumber = Double(secondNumberString) else {
            // print("Error - invalid second number")
            displayError("Please enter a valid second number", textField: secondNumberTextField)
            return
        }

        // Multiply numbers to find result
        let result = firstNumber * secondNumber
        
        // Format result - Method 1
        // resultLabel.text = String(format: "%.2f", result)

        // Format result - Method 2
        resultLabel.text = formatter.string(from: NSNumber(value: result))
    }
    
    func displayError(_ message: String, textField: UITextField) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        present(alertController, animated: true) {
            textField.text = ""
        }
    }
    
    // MARK: UIResponder methods
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }

    // MARK: UITextFieldDelegate methods
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        // Get the text that's currently in the text field.
        guard let oldString = textField.text else {
            return false
        }
        
        // Add the character(s) typed by the user to the string.
        let newString = oldString.replacingCharacters(in: Range(range, in: oldString)!, with: string)
        
        // If the resulting string is empty or just a leading minus sign, allow it.
        if newString.isEmpty || newString == "-" {
            return true
        }
        
        // If the resulting string can successfully be converted to a Double, allow it.
        // This can also work with Int.
        
        if let _ = Double(newString) {
            return true
        } else {
            return false
        }
    }
    
}

