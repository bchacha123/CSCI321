//
//  ViewController.swift
//  TextFieldDemo
//
//  Created by Kurt McMahon on 2/2/21.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var firstNumberTextField: UITextField!
    @IBOutlet weak var secondNumberTextField: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonPressed() {
        
        firstNumberTextField.resignFirstResponder()
        secondNumberTextField.resignFirstResponder()
        
        // Get first number and convert it to an integer
        guard let firstNumberString = firstNumberTextField.text, !firstNumberString.isEmpty, let firstNumber = Int(firstNumberString) else {
            // print("Error - invalid first number")
            displayError("Please enter a valid first number", textField: firstNumberTextField)
            return
        }
        
        // Get second number and convert it to an integer
        guard let secondNumberString = secondNumberTextField.text, !secondNumberString.isEmpty, let secondNumber = Int(secondNumberString) else {
            // print("Error - invalid second number")
            displayError("Please enter a valid second number", textField: secondNumberTextField)
            return
        }

        // Multiply numbers to find result
        let result = firstNumber * secondNumber
        
        // Put result in the result label
        resultLabel.text = "\(result)"
        
    }
    
    func displayError(_ message: String, textField: UITextField) {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        present(alertController, animated: true) {
            textField.text = ""
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // MARK: UIResponder methods
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
}

