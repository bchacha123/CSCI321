//
//  ContentView.swift
//  Weather
//
//  Created by Kurt McMahon on 3/25/21.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var weatherVM: WeatherViewModel
    
    init() {
        self.weatherVM = WeatherViewModel()
    }
    
    var body: some View {
        
        VStack {
            
            Text("Today's Weather")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.white)
                .padding()
            
            TextField("Enter city name", text: $weatherVM.cityName, onCommit: {
                weatherVM.search()
            })
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .font(.custom("Arial", size: 25))
                .padding()
                .fixedSize()
            Text(weatherVM.temperature)
                .font(.custom("Arial", size: 50))
                .foregroundColor(.white)
                .padding()
            
            Text(weatherVM.humidity)
                .font(.custom("Arial", size:50))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .padding()

        }
        .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity)
        .background(Color.blue)
        .edgesIgnoringSafeArea(.all)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
