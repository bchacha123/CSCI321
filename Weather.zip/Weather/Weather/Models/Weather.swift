//
//  Weather.swift
//  Weather
//
//  Created by Kurt McMahon on 3/25/21.
//

import Foundation

struct WeatherResponse: Decodable {
    let main: Weather
}

struct Weather: Decodable {
    var temp: Double?
    var humidity: Double?
}
