//
//  WeatherService.swift
//  Weather
//
//  Created by Kurt McMahon on 3/25/21.
//

import Foundation

class WeatherService {
    
    func getWeather(city: String, completion: @escaping(Weather?) ->()) {
        guard let url = URL(string: "https://api.openweathermap.org/data/2.5/weather?q=\(city)&APPID=5de5edd92a8e8058cec3c2ae70192e26&units=imperial") else {
            completion(nil)
            return
        }
        
        URLSession.shared.dataTask(with: url) {
            data, response, error in
            
            let httpResponse = response as? HTTPURLResponse
            if httpResponse!.statusCode != 200 {
                completion(nil)
                print("HTTP Error: status code \(httpResponse!.statusCode)")
            } else if data == nil && error != nil {
                completion(nil)
                print("No data download")
            } else {
                do {
                    let weatherResponse = try JSONDecoder().decode(WeatherResponse.self, from: data!)
                    completion(weatherResponse.main)
                } catch {
                    completion(nil)
                    print("Unable to decode JSON data")
                }
            }
        }.resume()
    }
}

