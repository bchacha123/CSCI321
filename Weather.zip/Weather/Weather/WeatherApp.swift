//
//  WeatherApp.swift
//  Weather
//
//  Created by Kurt McMahon on 3/25/21.
//

import SwiftUI

@main
struct WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
