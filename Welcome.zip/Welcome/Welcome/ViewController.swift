//
//  ViewController.swift
//  Welcome
//
//  Created by Kurt McMahon on 1/21/21.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    // MARK: Outlets
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var welcomeButton: UIButton!
    @IBOutlet weak var imageView: UIImageView!
    
    // MARK: UIViewController methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        titleLabel.isHidden = true
        imageView.alpha = 0.0
        // nameTextField.delegate = self
    }

    // MARK: Actions
    
    /**
     Responds to button press.
     */
    @IBAction func buttonPressed() {
        
        // Get user's name and validate it.
        
        if let name = nameTextField.text, !name.isEmpty {
            titleLabel.text = "Welcome to iOS Programming, \(name)!"
        } else {
            titleLabel.text = "Welcome to iOS Programming!"
        }
        
        nameTextField.resignFirstResponder()
        
        titleLabel.center = CGPoint(x: titleLabel.center.x, y: titleLabel.center.y - 500)
        titleLabel.isHidden = false
        
        UIView.animate(withDuration: 2.0, animations: {
            self.titleLabel.center = CGPoint(x: self.titleLabel.center.x, y: self.titleLabel.center.y + 500)
            self.imageView.alpha = 1.0
        })

    }
    
    // MARK: UITextFieldDelegate methods
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

